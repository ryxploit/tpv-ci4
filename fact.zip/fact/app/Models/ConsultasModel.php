<?php

namespace App\Models;

use CodeIgniter\Model;

class ConsultasModel extends Model
{
    protected $table      = 'consultas';
    protected $primaryKey = 'id_consulta';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['id_cliente', 'id_cirugia', 'diagnostico', 'receta'];

    protected $useTimestamps = true;
    protected $createdField  = 'fecha_alta';
    protected $updatedField  = '';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;


    public function obtener($id_consulta){
      $this->select('consultas.*, c.nombre AS nombre , c.telefono AS telefono, c.correo AS correo');
      $this->join('clientes AS c', 'consultas.id_consulta = c.id_consulta');
      $this->where('c.id_consulta', $id_consulta);
      $this->orderBy('consultas.id_consulta', 'DESC');
      $datos = $this->findAll();
      //print_r($this->GetLastQuery());
      return $datos;
    }
}


?>
