<?php

namespace App\Models;

use CodeIgniter\Model;

class ClientesModel extends Model
{
    protected $table      = 'clientes';
    protected $primaryKey = 'id_cliente';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['nombre', 'direccion', 'telefono', 'correo', 'text_area', 'activo'];

    protected $useTimestamps = true;
    protected $createdField  = 'fecha_alta';
    protected $updatedField  = 'fecha_edit';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;

    public function obtener($id_cliente){
      $this->select('clientes.*, c.diagnostico AS diagnostico , c.receta AS receta, c.fecha_alta AS fecha_consulta, c.id_consulta AS id_consulta, c.id_cirugia AS id_cirugia');
      $this->join('consultas AS c', 'clientes.id_cliente = c.id_cliente');
      $this->where('c.id_cliente', $id_cliente);
      $this->orderBy('clientes.id_cliente', 'DESC');
      $datos = $this->findAll();
      //print_r($this->GetLastQuery());
      return $datos;
    }

    public function fetch($id_cliente)
    {
      // code...
    //  $query = $db->query("SELECT * FROM `clientes` WHERE id_cliente = ". $id_cliente);
    $this->select();
    $this->where('id_cliente', $id_cliente);


      $row = $this->findAll();

      return $row;


    }
}


?>
