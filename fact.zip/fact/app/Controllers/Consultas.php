<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ConsultasModel;
use App\Models\CirugiasModel;

class Consultas extends BaseController
{
    protected $consultas, $cirugias;
    protected $reglas;

    public function __construct()
    {
        $this->consultas = new ConsultasModel();

        helper(['form']);

        $this->reglas = [
            'nombre' => [
                'rules' => 'required',
                    'errors' => [
                        'required' => 'El campo {field} es obligatorio.'
                    ]
            ]
        ];
    }

    public function index()
    {
        $consultas = $this->consultas->findAll();
        $data = ['titulo' => ' Consultas', 'datos' => $consultas];

        echo view('header');
        echo view('consultas/consultas', $data);
        echo view('footer');
    }

    public function eliminados($activo = 0)
    {
        $consultas = $this->consultas->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Pacientes eliminados', 'datos' => $consultas];

        echo view('header');
        echo view('consultas/eliminados', $data);
        echo view('footer');
    }

    public function nuevo()
    {

        $data = ['titulo' => ' Agregar Consulta'];

        echo view('header');
        echo view('consultas/nuevo', $data);
        echo view('footer');
    }


}

?>
