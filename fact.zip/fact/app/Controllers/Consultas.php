<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ConsultasModel;

class Consultas extends BaseController
{
    protected $consultas;
    protected $reglas;

    public function __construct()
    {
        $this->consultas = new ConsultasModel();

        helper(['form']);

        $this->reglas = [
            'nombre' => [
                'rules' => 'required',
                    'errors' => [
                        'required' => 'El campo {field} es obligatorio.'
                    ]
            ]
        ];
    }

    public function index()
    {
        $consultas = $this->consultas->findAll();
        $data = ['titulo' => ' Consultas', 'datos' => $consultas];

        echo view('header');
        echo view('consultas/consultas', $data);
        echo view('footer');
    }

    public function eliminados($activo = 0)
    {
        $consultas = $this->consultas->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Pacientes eliminados', 'datos' => $consultas];

        echo view('header');
        echo view('consultas/eliminados', $data);
        echo view('footer');
    }

    public function nuevo()
    {

        $data = ['titulo' => ' Agregar Consulta'];

        echo view('header');
        echo view('consultas/nuevo', $data);
        echo view('footer');
    }

    public function insertar()
    {
        if( $this->request->getMethod() == "post" && $this->validate($this->reglas)){


            $this->consultas->save([
                'nombre' => $this->request->getPost('nombre'),
                'direccion' => $this->request->getPost('direccion'),
                'telefono' => $this->request->getPost('telefono'),
                'correo' => $this->request->getPost('correo'),
                'text_area' => $this->request->getPost('text_area')
            ]);

            return redirect()->to(base_url().'/consultas');

        } else {

            $data = ['titulo' => ' Agregar paciente', 'validation' => $this->validator];

            echo view('header');
            echo view('consultas/nuevo', $data);
            echo view('footer');
            }

    }

    public function editar($id_cliente, $valid=null)
    {
        $cliente = $this->consultas->where('id_cliente', $id_cliente)->first();

        if ($valid != null) {
            $data = ['titulo' => ' Editar paciente', 'cliente' => $cliente, 'validation' => $valid];
        } else {
            $data = ['titulo' => ' Editar paciente',  'cliente' => $cliente];
        }


        echo view('header');
        echo view('consultas/editar', $data);
        echo view('footer');
    }

    public function actualizar()
    {
        $this->consultas->update($this->request->getPost('id_cliente'), [
            'nombre' => $this->request->getPost('nombre'),
                'direccion' => $this->request->getPost('direccion'),
                'telefono' => $this->request->getPost('telefono'),
                'correo' => $this->request->getPost('correo'),
                'text_area' => $this->request->getPost('text_area')
        ]);

        return redirect()->to(base_url().'/consultas');
    }

    public function eliminar($id_cliente)
    {
        $this->consultas->update($id_cliente, ['activo' => 0]);
        return redirect()->to(base_url().'/consultas');
    }

    public function reingresar($id_cliente)
    {
        $this->consultas->update($id_cliente, ['activo' => 1]);
        return redirect()->to(base_url().'/consultas');
    }

    public function autocompleteData()
    {

        $returnData = array();

        $valor = $this->request->getGet('term');

        $consultas = $this->consultas->like('nombre', $valor)->where('activo', 1)->findAll();

        if (!empty($consultas)) {
            foreach($consultas as $row){
                $data['id'] = $row['id_cliente'];
                $data['value'] = $row['nombre'];
                array_push($returnData, $data);
            }
        }

        echo json_encode($returnData);
    }

}

?>
