<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\LimpiezaModel;
use App\Models\UnidadesModel;
use App\Models\CategoriasModel;

class Limpieza extends BaseController
{
    protected $limpieza;
    protected $reglas;

    public function __construct()
    {
        $this->limpieza = new LimpiezaModel();
        $this->unidades = new UnidadesModel();
        $this->categorias = new CategoriasModel();

        helper(['form']);

        $this->reglas = [
            'codigo' => [
                'rules' => 'required|is_unique[limpieza.codigo]',
                    'errors' => [
                        'required' => 'El campo {field} es obligatorio.',
                        'is_unique' => 'El {field} ya esta registrado en el sistema.'
                    ]
            ],
            'nombre ' => [
                'rules' => 'required',
                    'errors' => [
                        'required' => 'El campo {field} es obligatorio.'
                    ]
            ]
        ];
    }

    public function index($activo = 1)
    {
        $limpieza = $this->limpieza->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Articulos de limpieza', 'datos' => $limpieza];

        echo view('header');
        echo view('limpieza/limpieza', $data);
        echo view('footer');
    }

    public function eliminados($activo = 0)
    {
        $limpieza = $this->limpieza->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Articulos Eliminados', 'datos' => $limpieza];

        echo view('header');
        echo view('limpieza/eliminados', $data);
        echo view('footer');
    }

    public function nuevo()
    {

        $unidades = $this->unidades->where('activo', 1)->findAll();
        $categorias = $this->categorias->where('activo', 1)->findAll();

        $data = ['titulo' => ' Agregar Articulo', 'unidades' => $unidades, 'categorias' => $categorias];

        echo view('header');
        echo view('limpieza/nuevo', $data);
        echo view('footer');
    }

    public function insertar()
    {
        if( $this->request->getMethod() == "post" && $this->validate($this->reglas)){


            $this->limpieza->save([
                'codigo' => $this->request->getPost('codigo'),
                'nombre' => $this->request->getPost('nombre'),
                // 'precio_venta' => $this->request->getPost('precio_venta'),
                'precio_compra' => $this->request->getPost('precio_compra'),
                'existencias' => $this->request->getPost('existencias'),
                'stock_minimo' => $this->request->getPost('stock_minimo'),
                'id_unidad' => $this->request->getPost('id_unidad'),
                'id_categoria' => $this->request->getPost('id_categoria')
            ]);

            return redirect()->to(base_url().'/limpieza');

        } else {
            $unidades = $this->unidades->where('activo', 1)->findAll();
            $categorias = $this->categorias->where('activo', 1)->findAll();

            $data = ['titulo' => ' Agregar producto', 'unidades' => $unidades, 'categorias' => $categorias, 'validation' => $this->validator];

            echo view('header');
            echo view('limpieza/nuevo', $data);
            echo view('footer');
            }

    }

    public function editar($id_limpieza, $valid=null)
    {
        $unidades = $this->unidades->where('activo', 1)->findAll();
        $categorias = $this->categorias->where('activo', 1)->findAll();
        $limpieza = $this->limpieza->where('id_limpieza', $id_limpieza)->first();

        if ($valid != null) {
            $data = ['titulo' => ' Editar producto', 'unidades' => $unidades, 'categorias' => $categorias, 'limpieza' => $limpieza, 'validation' => $valid];
        } else {
            $data = ['titulo' => ' Editar producto', 'unidades' => $unidades, 'categorias' => $categorias, 'limpieza' => $limpieza];
        }


        echo view('header');
        echo view('limpieza/editar', $data);
        echo view('footer');
    }

    public function descontar($id_limpieza, $valid=null)
    {
        $limpieza = $this->limpieza->where('id_limpieza', $id_limpieza)->first();

        if ($valid != null) {
            $data = ['titulo' => ' Descontar articulo', 'limpieza' => $limpieza, 'validation' => $valid];
        } else {
            $data = ['titulo' => ' Descontar articulo', 'limpieza' => $limpieza];
        }


        echo view('header');
        echo view('limpieza/descontar', $data);
        echo view('footer');
    }

    public function actualizar()
    {
        $this->limpieza->update($this->request->getPost('id_limpieza'), [
            'codigo' => $this->request->getPost('codigo'),
            'nombre' => $this->request->getPost('nombre'),
            // 'precio_venta' => $this->request->getPost('precio_venta'),
            'precio_compra' => $this->request->getPost('precio_compra'),
            'stock_minimo' => $this->request->getPost('stock_minimo'),
            'inventariable' => $this->request->getPost('inventariable'),
            'id_unidad' => $this->request->getPost('id_unidad'),
            'id_categoria' => $this->request->getPost('id_categoria')
        ]);
                                                                                                                                                                        
        return redirect()->to(base_url().'/limpieza');
    }

    public function actualizar_descuento()
    {
        $this->limpieza->update($this->request->getPost('id_limpieza'), [
            'existencias' => $this->request->getPost('existencias')
        ]);

        return redirect()->to(base_url().'/limpieza');
    }

    public function eliminar($id_limpieza)
    {
        $this->limpieza->update($id_limpieza, ['activo' => 0]);
        return redirect()->to(base_url().'/limpieza');
    }

    public function reingresar($id_limpieza)
    {
        $this->limpieza->update($id_limpieza, ['activo' => 1]);
        return redirect()->to(base_url().'/limpieza');
    }

    public function buscarPorCodigo($codigo)
    {
        $this->productos->select('*');
        $this->productos->where('codigo', $codigo);
        $this->productos->where('activo', 1);
        $datos = $this->limpieza->get()->getRow();

        $res['existe'] = false;
        $res['datos'] = '';
        $res['error'] = '';

        if ($datos) {
            $res['datos'] = $datos;
            $res['existe'] = true;
        } else {
            $res['error'] = 'No existe el producto';
            $res['existe'] = false;
        };

        echo json_encode($res);
    }

    public function autocompleteData()
    {

        $returnData = array();

        $valor = $this->request->getGet('term');

        $limpieza = $this->limpieza->like('codigo', $valor)->where('activo', 1)->findAll();

        if (!empty($limpieza)) {
            foreach($limpieza as $row){
                $data['id'] = $row['id_limpieza'];
                $data['value'] = $row['codigo'];
                $data['label'] = $row['codigo']. ' - '.$row['nombre'];
                array_push($returnData, $data);
            }
        }

        echo json_encode($returnData);
    }

}

?>
