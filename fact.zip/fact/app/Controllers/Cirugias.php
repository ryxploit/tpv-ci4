<?php 

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\CirugiasModel;

class Cirugias extends BaseController
{
    protected $cirugias;
    protected $reglas;

    public function __construct()
    {
        $this->cirugias = new CirugiasModel();
        helper(['form']);

        $this->reglas = [
            'nombre' => [
                'rules' => 'required',
                    'errors' => [
                        'required' => 'El campo {field} es obligatorio.'
                    ]
            ]
        ];
    }

    public function index($activo = 1)
    {
        $cirugias = $this->cirugias->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Cirugias', 'datos' => $cirugias];

        echo view('header');
        echo view('cirugias/cirugias', $data);
        echo view('footer');
    }
 
    public function eliminados($activo = 0)
    {
        $cirugias = $this->cirugias->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Cirugias eliminadas', 'datos' => $cirugias];

        echo view('header');
        echo view('cirugias/eliminados', $data);
        echo view('footer');
    }

    public function nuevo()
    {

        $data = ['titulo' => ' Agregar cirugias'];

        echo view('header'); 
        echo view('cirugias/nuevo', $data);
        echo view('footer');
    }

    public function insertar()
    {
        if( $this->request->getMethod() == "post" && $this->validate($this->reglas)){

            $this->cirugias->save(['nombre' => $this->request->getPost('nombre')]);
            return redirect()->to(base_url().'/cirugias');

        } else {
            
            $data = ['titulo' => ' Agregar cirugias', 'validation' => $this->validator];

            echo view('header'); 
            echo view('cirugias/nuevo', $data);
            echo view('footer');
        }
    }

    public function editar($id_cirugia, $valid=null)
    {
        $unidad = $this->cirugias->where('id_cirugia',$id_cirugia)->first();

        if ($valid != null) {
            $data = ['titulo' => ' Editar Cirugia', 'datos' => $unidad, 'validation' => $valid];
        } else {
            $data = ['titulo' => ' Editar Cirugia', 'datos' => $unidad];
        }

        echo view('header'); 
        echo view('cirugias/editar', $data);
        echo view('footer');
    }

    public function actualizar()
    {
        if( $this->request->getMethod() == "post" && $this->validate($this->reglas)){
            $this->cirugias->update($this->request->getPost('id_cirugia'), ['nombre' => $this->request->getPost('nombre')]);
            return redirect()->to(base_url().'/cirugias');
        }else{
            return ($this->editar($this->request->getPost('id_cirugia'), $this->validator));
        }
    }

    public function eliminar($id_cirugia)
    {
        $this->cirugias->update($id_cirugia, ['activo' => 0]);
        return redirect()->to(base_url().'/cirugias');
    }

    public function reingresar($id_cirugia)
    {
        $this->cirugias->update($id_cirugia, ['activo' => 1]);
        return redirect()->to(base_url().'/cirugias');
    }
    
}

?>