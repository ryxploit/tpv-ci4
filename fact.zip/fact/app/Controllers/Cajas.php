<?php 

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\CajasModel;

class Cajas extends BaseController
{
    protected $cajas; 
    protected $reglas;

    public function __construct()
    {
        $this->cajas = new CajasModel();
        helper(['form']);

        $this->reglas = [
            'numero_caja' => [
                'rules' => 'required|is_unique[cajas.numero_caja]',
                    'errors' => [
                        'required' => 'El campo {field} es obligatorio.', 
                        'is_unique' => 'El {field} ya esta registrado en el sistema.'
                    ]
            ],
            'nombre' => [
                'rules' => 'required',
                    'errors' => [
                        'required' => 'El campo {field} es obligatorio.'
                    ]
            ],
            'folio' => [
                'rules' => 'required',
                    'errors' => [
                        'required' => 'El campo {field} es obligatorio.'
                    ]
            ]
        ];
    }

    public function index($activo = 1)
    {
        $cajas = $this->cajas->where('activo',$activo)->findAll();
        $data = ['titulo' => 'Cajas', 'datos' => $cajas];

        echo view('header');
        echo view('cajas/cajas', $data);
        echo view('footer');
    }

    public function eliminados($activo = 0)
    {
        $cajas = $this->cajas->where('activo',$activo)->findAll();
        $data = ['titulo' => 'Unidades eliminadas', 'datos' => $cajas];

        echo view('header');
        echo view('cajas/eliminados', $data);
        echo view('footer');
    }

    public function nuevo()
    {

        $data = ['titulo' => 'Agregar caja'];

        echo view('header'); 
        echo view('cajas/nuevo', $data);
        echo view('footer');
    }

    public function insertar()
    {
        if( $this->request->getMethod() == "post" && $this->validate($this->reglas)){

            $this->cajas->save([
                'numero_caja' => $this->request->getPost('numero_caja'), 
                'nombre' => $this->request->getPost('nombre'), 
                'folio' => $this->request->getPost('folio'),
                'activo' => 1
            ]);

            return redirect()->to(base_url().'/cajas');

        } else {
            
            $data = ['titulo' => 'Agregar caja', 'validation' => $this->validator];

            echo view('header'); 
            echo view('cajas/nuevo', $data);
            echo view('footer');
            }
        
    }

    public function editar($id_caja, $valid=null)
    {
        $cajas = $this->cajas->where('id_caja',$id_caja)->first();

        if ($valid != null) {
            $data = ['titulo' => 'Editar caja', 'datos' => $cajas, 'validation' => $valid];
        } else {
            $data = ['titulo' => 'Editar caja', 'datos' => $cajas];
        }
        

        echo view('header'); 
        echo view('cajas/editar', $data);
        echo view('footer');
    }

    public function actualizar()
    {
        if( $this->request->getMethod() == "post" && $this->validate($this->reglas)){
            $this->cajas->update($this->request->getPost('id_caja'),[
                 'numero_caja' => $this->request->getPost('numero_caja'), 
                 'nombre' => $this->request->getPost('nombre'),
                 'folio' => $this->request->getPost('folio')
             ]);
            return redirect()->to(base_url().'/cajas');
        } else {
            return ($this->editar($this->request->getPost('id_caja'), $this->validator));
        }
    }

    public function eliminar($id_caja)
    {
        $this->cajas->update($id_caja, ['activo' => 0]);
        return redirect()->to(base_url().'/cajas');
    }

    public function reingresar($id_caja)
    {
        $this->cajas->update($id_caja, ['activo' => 1]);
        return redirect()->to(base_url().'/cajas');
    }
    
}

?>