<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ClientesModel;
use App\Models\ConsultasModel;
use App\Models\ConfiguracionModel;

class Clientes extends BaseController
{
    protected $clientes, $consultas, $configuracion;
    protected $reglas;

    public function __construct()
    {
        $this->clientes = new ClientesModel();
        $this->consultas = new ConsultasModel();
        $this->configuracion = new ConfiguracionModel();

        helper(['form']);

        $this->reglas = [
            'nombre' => [
                'rules' => 'required',
                    'errors' => [
                        'required' => 'El campo {field} es obligatorio.'
                    ]
            ]
        ];
    }

    public function index($activo = 1)
    {
        $clientes = $this->clientes->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Pacientes', 'datos' => $clientes];

        echo view('header');
        echo view('clientes/clientes', $data);
        echo view('footer');
    }

    public function consulta($id_cliente)
    {
        $datos = $this->clientes->obtener($id_cliente);
        $query = $this->clientes->fetch($id_cliente);

        $data = ['titulo' => ' Pacientes', 'datos' => $datos, 'datoos' => $query];

        echo view('header');
        echo view('clientes/consultas', $data);
        echo view('footer');
    }



    public function eliminados($activo = 0)
    {
        $clientes = $this->clientes->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Pacientes eliminados', 'datos' => $clientes];

        echo view('header');
        echo view('clientes/eliminados', $data);
        echo view('footer');
    }

    public function nuevo()
    {

        $data = ['titulo' => ' Agregar paciente'];

        echo view('header');
        echo view('clientes/nuevo', $data);
        echo view('footer');
    }

    public function nuevo_consulta($id_cliente)
    {

        $data = ['titulo' => ' Agregar consulta' , 'cliente_id' => $id_cliente];

        echo view('header');
        echo view('clientes/nuevo_consulta', $data);
        echo view('footer');
    }

    public function insertar()
    {
        if( $this->request->getMethod() == "post" && $this->validate($this->reglas)){


            $this->clientes->save([
                'nombre' => $this->request->getPost('nombre'),
                'direccion' => $this->request->getPost('direccion'),
                'telefono' => $this->request->getPost('telefono'),
                'correo' => $this->request->getPost('correo')
            ]);

            return redirect()->to(base_url().'/clientes');

        } else {

            $data = ['titulo' => ' Agregar paciente', 'validation' => $this->validator];

            echo view('header');
            echo view('clientes/nuevo', $data);
            echo view('footer');
            }

    }

    public function insertar_consulta()
    {

            $this->consultas->save([

                'diagnostico' => $this->request->getPost('diagnostico_medico'),
                'id_cliente' => $this->request->getPost('id_cliente'),
                'receta' => $this->request->getPost('receta')
            ]);

            return redirect()->to(base_url().'/clientes');


    }

    public function editar($id_cliente, $valid=null)
    {
        $cliente = $this->clientes->where('id_cliente', $id_cliente)->first();

        if ($valid != null) {
            $data = ['titulo' => ' Editar paciente', 'cliente' => $cliente, 'validation' => $valid];
        } else {
            $data = ['titulo' => ' Editar paciente',  'cliente' => $cliente];
        }


        echo view('header');
        echo view('clientes/editar', $data);
        echo view('footer');
    }

    public function editar_consulta($id_consulta, $valid=null)
    {
        $cliente = $this->consultas->where('id_consulta', $id_consulta)->first();

        if ($valid != null) {
            $data = ['titulo' => ' Expediente clinico', 'cliente' => $cliente, 'validation' => $valid];
        } else {
            $data = ['titulo' => ' Expediente clinico',  'cliente' => $cliente];
        }


        echo view('header');
        echo view('clientes/editar_consulta', $data);
        echo view('footer');
    }

    public function actualizar()
    {
        $this->clientes->update($this->request->getPost('id_cliente'), [
            'nombre' => $this->request->getPost('nombre'),
                'direccion' => $this->request->getPost('direccion'),
                'telefono' => $this->request->getPost('telefono'),
                'correo' => $this->request->getPost('correo')
        ]);

        return redirect()->to(base_url().'/clientes');
    }

    public function actualizar_consulta()
    {
        $this->consultas->update($this->request->getPost('id_consulta'), [
            'diagnostico' => $this->request->getPost('diagnostico_medico'),
                'receta' => $this->request->getPost('receta')
        ]);

        return redirect()->to(base_url()."/clientes/muestraCompraPdf/");
    }

    public function eliminar($id_cliente)
    {
        $this->clientes->update($id_cliente, ['activo' => 0]);
        return redirect()->to(base_url().'/clientes');
    }

    public function reingresar($id_cliente)
    {
        $this->clientes->update($id_cliente, ['activo' => 1]);
        return redirect()->to(base_url().'/clientes');
    }

    public function autocompleteData()
    {

        $returnData = array();

        $valor = $this->request->getGet('term');

        $clientes = $this->clientes->like('nombre', $valor)->where('activo', 1)->findAll();

        if (!empty($clientes)) {
            foreach($clientes as $row){
                $data['id'] = $row['id_cliente'];
                $data['value'] = $row['nombre'];
                array_push($returnData, $data);
            }
        }

        echo json_encode($returnData);
    }

    function muestraCompraPdf($id_consulta){
        $data['id_consulta'] = $id_consulta;
        echo view('header');
        echo view('clientes/ver_compra_pdf', $data);
        echo view('footer');
    }

    public function generaCompraPdf($id_consulta)
    {
        $datosCompra = $this->consultas->where('id_consulta', $id_consulta)->first();
        $detallecompra = $this->consultas->select('*')->where('id_consulta', $id_consulta)->findAll();
        $nombreTienda = $this->configuracion->select('valor')->where('nombre', 'tienda_nombre')->get()->getRow()->valor;
        $direccionTienda = $this->configuracion->select('valor')->where('nombre', 'tienda_direccion')->get()->getRow()->valor;


        $pdf = new \FPDF('P', 'mm', 'letter');
        $pdf->AddPage();
        $pdf->SetMargins(10, 10, 10);
        $pdf->SetTitle(" Consulta");
        $pdf->SetFont('Arial', 'B', 10);

        $pdf->Cell(195, 5, "Consulta", 0, 1, 'C');
        $pdf->SetFont('Arial', 'B', 9);

        $pdf->image(base_url() . '/images/logo.png', 170, 0, 40, 40, 'PNG');
        $pdf->Cell(50, 5, $nombreTienda, 0, 1, 'L');
        $pdf->Cell(20, 5, utf8_decode('Direccion: '), 0, 0, 'L');
        $pdf->SetFont('Arial', '', 9);
        $pdf->Cell(50, 5, $direccionTienda, 0, 1, 'L');
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->Cell(25, 5, utf8_decode('Fecha y hora: '), 0, 0, 'L');
        $pdf->SetFont('Arial', '', 9);
        $pdf->Cell(50, 5, $datosCompra['fecha_alta'], 0, 1, 'L');

        $pdf->Ln();
        $pdf->Ln();

        $pdf->SetFont('Arial', 'B', 8);
        $pdf->Setfillcolor(0, 0, 0);
        $pdf->SetTextColor(255, 255, 255);
        $pdf->Cell(196, 5, 'Detalle de consulta', 1, 1, 'C', 1);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(97, 5, 'Diagnostico', 1, 0, 'C');
        $pdf->Cell(99, 5, 'Receta', 1, 1, 'C');

        $pdf->SetFont('Arial', '', 8);

        $contador = 1;
        $x = $pdf->GetX();
        $y = $pdf->GetY();

        foreach ($detallecompra as $row) {
          $pdf->MultiCell(97, 5, $row['diagnostico'], 1, 'L', 0, 0, $x, $y, true, 0, false, true, 0);
          $pdf->MultiCell(97, 5, $row['diagnostico'], 1, 'L', 0, 0, $x, $y, true, 0, false, true, 0);
          
            $contador++;
        }

        $this->response->setHeader('Content-Type', 'application/pdf');
        $pdf->Output("consulta_pdf.pdf", "I");

    }

}

?>
