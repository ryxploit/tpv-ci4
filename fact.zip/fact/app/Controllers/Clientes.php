<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ClientesModel;
use App\Models\ConsultasModel;

class Clientes extends BaseController
{
    protected $clientes, $consultas;
    protected $reglas;




    public function __construct()
    {
        $this->clientes = new ClientesModel();
        $this->consultas = new ConsultasModel();

        helper(['form']);

        $this->reglas = [
            'nombre' => [
                'rules' => 'required',
                    'errors' => [
                        'required' => 'El campo {field} es obligatorio.'
                    ]
            ]
        ];
    }

    public function index($activo = 1)
    {
        $clientes = $this->clientes->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Pacientes', 'datos' => $clientes];

        echo view('header');
        echo view('clientes/clientes', $data);
        echo view('footer');
    }

    public function consulta($id_cliente)
    {
        $datos = $this->clientes->obtener($id_cliente);
      $query = $this->clientes->fetch($id_cliente);

        $data = ['titulo' => ' Pacientes', 'datos' => $datos, 'datoos' => $query];

        echo view('header');
        echo view('clientes/consultas', $data);
        echo view('footer');
    }



    public function eliminados($activo = 0)
    {
        $clientes = $this->clientes->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Pacientes eliminados', 'datos' => $clientes];

        echo view('header');
        echo view('clientes/eliminados', $data);
        echo view('footer');
    }

    public function nuevo()
    {

        $data = ['titulo' => ' Agregar paciente'];

        echo view('header');
        echo view('clientes/nuevo', $data);
        echo view('footer');
    }

    public function nuevo_consulta($id_cliente)
    {

        $data = ['titulo' => ' Agregar consulta' , 'cliente_id' => $id_cliente];

        echo view('header');
        echo view('clientes/nuevo_consulta', $data);
        echo view('footer');
    }

    public function insertar()
    {
        if( $this->request->getMethod() == "post" && $this->validate($this->reglas)){


            $this->clientes->save([
                'nombre' => $this->request->getPost('nombre'),
                'direccion' => $this->request->getPost('direccion'),
                'telefono' => $this->request->getPost('telefono'),
                'correo' => $this->request->getPost('correo')
            ]);

            return redirect()->to(base_url().'/clientes');

        } else {

            $data = ['titulo' => ' Agregar paciente', 'validation' => $this->validator];

            echo view('header');
            echo view('clientes/nuevo', $data);
            echo view('footer');
            }

    }

    public function insertar_consulta()
    {

            $this->consultas->save([

                'diagnostico' => $this->request->getPost('diagnostico_medico'),
                'id_cliente' => $this->request->getPost('id_cliente'),
                'receta' => $this->request->getPost('receta')
            ]);

            return redirect()->to(base_url().'/clientes');


    }

    public function editar($id_cliente, $valid=null)
    {
        $cliente = $this->clientes->where('id_cliente', $id_cliente)->first();

        if ($valid != null) {
            $data = ['titulo' => ' Editar paciente', 'cliente' => $cliente, 'validation' => $valid];
        } else {
            $data = ['titulo' => ' Editar paciente',  'cliente' => $cliente];
        }


        echo view('header');
        echo view('clientes/editar', $data);
        echo view('footer');
    }

    public function editar_consulta($id_consulta, $valid=null)
    {
        $cliente = $this->consultas->where('id_consulta', $id_consulta)->first();

        if ($valid != null) {
            $data = ['titulo' => ' Expediente clinico', 'cliente' => $cliente, 'validation' => $valid];
        } else {
            $data = ['titulo' => ' Expediente clinico',  'cliente' => $cliente];
        }


        echo view('header');
        echo view('clientes/editar_consulta', $data);
        echo view('footer');
    }

    public function actualizar()
    {
        $this->clientes->update($this->request->getPost('id_cliente'), [
            'nombre' => $this->request->getPost('nombre'),
                'direccion' => $this->request->getPost('direccion'),
                'telefono' => $this->request->getPost('telefono'),
                'correo' => $this->request->getPost('correo')
        ]);

        return redirect()->to(base_url().'/clientes');
    }

    public function actualizar_consulta()
    {
        $this->consultas->update($this->request->getPost('id_consulta'), [
            'diagnostico' => $this->request->getPost('diagnostico_medico'),
                'receta' => $this->request->getPost('receta')
        ]);

        return redirect()->to(base_url()."/clientes/muestraCompraPdf/");
    }

    public function eliminar($id_cliente)
    {
        $this->clientes->update($id_cliente, ['activo' => 0]);
        return redirect()->to(base_url().'/clientes');
    }

    public function reingresar($id_cliente)
    {
        $this->clientes->update($id_cliente, ['activo' => 1]);
        return redirect()->to(base_url().'/clientes');
    }

    public function autocompleteData()
    {

        $returnData = array();

        $valor = $this->request->getGet('term');

        $clientes = $this->clientes->like('nombre', $valor)->where('activo', 1)->findAll();

        if (!empty($clientes)) {
            foreach($clientes as $row){
                $data['id'] = $row['id_cliente'];
                $data['value'] = $row['nombre'];
                array_push($returnData, $data);
            }
        }

        echo json_encode($returnData);
    }

    public function guarda()
    {

        $id_consulta = $this->request->getPost('id_consulta');

        $this->consultas = new ConsultasModel();

        return redirect()->to(base_url()."/clientes/muestraCompraPdf/");

    }

    function muestraCompraPdf($id_venta){
        $data['id_venta'] = $id_venta;
        echo view('header');
        echo view('clientes/ver_compra_pdf', $data);
        echo view('footer');
    }

    public function generaCompraPdf($id_compra)
    {
        $datosCompra = $this->compras->where('id_compra', $id_compra)->first();
        $detallecompra = $this->detalle_compra->select('*')->where('id_compra', $id_compra)->findAll();
        $nombreTienda = $this->configuracion->select('valor')->where('nombre', 'tienda_nombre')->get()->getRow()->valor;
        $direccionTienda = $this->configuracion->select('valor')->where('nombre', 'tienda_direccion')->get()->getRow()->valor;


        $pdf = new \FPDF('P', 'mm', 'letter');
        $pdf->AddPage();
        $pdf->SetMargins(10, 10, 10);
        $pdf->SetTitle("Compra");
        $pdf->SetFont('Arial', 'B', 10);

        $pdf->Cell(195, 5, "Entrada de productos", 0, 1, 'C');
        $pdf->SetFont('Arial', 'B', 9);

        $pdf->image(base_url() . '/images/php.png', 185, 10, 20, 20, 'PNG');
        $pdf->Cell(50, 5, $nombreTienda, 0, 1, 'L');
        $pdf->Cell(20, 5, utf8_decode('Direccion: '), 0, 0, 'L');
        $pdf->SetFont('Arial', '', 9);
        $pdf->Cell(50, 5, $direccionTienda, 0, 1, 'L');
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->Cell(25, 5, utf8_decode('Fecha y hora: '), 0, 0, 'L');
        $pdf->SetFont('Arial', '', 9);
        $pdf->Cell(50, 5, $datosCompra['fecha_alta'], 0, 1, 'L');

        $pdf->Ln();

        $pdf->SetFont('Arial', 'B', 8);
        $pdf->Setfillcolor(0, 0, 0);
        $pdf->SetTextColor(255, 255, 255);
        $pdf->Cell(196, 5, 'Detalle de productos', 1, 1, 'C', 1);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(14, 5, 'No', 1, 0, 'L');
        $pdf->Cell(25, 5, 'Codigo', 1, 0, 'L');
        $pdf->Cell(77, 5, 'Nombre', 1, 0, 'L');
        $pdf->Cell(25, 5, 'Precio', 1, 0, 'L');
        $pdf->Cell(25, 5, 'Cantidad', 1, 0, 'L');
        $pdf->Cell(30, 5, 'Importe', 1, 1, 'L');

        $pdf->SetFont('Arial', '', 8);

        $contador = 1;

        foreach ($detallecompra as $row) {
            $pdf->Cell(14, 5, $contador, 1, 0, 'L');
            $pdf->Cell(25, 5, $row['id_producto'], 1, 0, 'L');
            $pdf->Cell(77, 5, $row['nombre'], 1, 0, 'L');
            $pdf->Cell(25, 5, $row['precio'], 1, 0, 'L');
            $pdf->Cell(25, 5, $row['cantidad'], 1, 0, 'L');
            $importe = number_format($row['precio'] * $row['cantidad'], 2, '.', ',');
            $pdf->Cell(30, 5, '$ ' . $importe, 1, 1, 'R');
            $contador++;
        }

        $pdf->Ln();
        $pdf->SetFont('Arial', 'B', 8);
        $pdf->Cell(195, 5, 'Total $ '. number_format($datosCompra['total'], 2, '.', ','), 0, 1, 'R');

        $this->response->setHeader('Content-Type', 'application/pdf');
        $pdf->Output("compra_pdf.pdf", "I");

    }

}

?>
