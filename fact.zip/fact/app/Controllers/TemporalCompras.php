<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\TemporalComprasModel;
use App\Models\ProductosModel;

class TemporalCompras extends BaseController
{
    protected $temporal_compras, $productos;

    public function __construct()
    {
        $this->temporal_compras = new TemporalComprasModel();
        $this->productos = new ProductosModel();
    }


    public function inserta($id_producto, $cantidad, $id_compra)
    {

        $error = '';

        $producto = $this->productos->where('id_producto', $id_producto)->first();

        if ($producto) {

            $datosExiste = $this->temporal_compras->porIdProductoCompra($id_producto, $id_compra);

            if ($datosExiste) {
                $cantidad = $datosExiste->cantidad + $cantidad;
                $total = $cantidad * $datosExiste->precio;
                $iva = $total * 0.16;
                $subtotal = $total - $iva;

                $this->temporal_compras->actualizarProductoCompra($id_producto, $id_compra, $cantidad, $subtotal, $iva, $total);

            } else {
                 $total = $cantidad * $producto['precio_compra'];
                 $iva = $total * 0.16;
                 $subtotal = $total - $iva;

                 $this->temporal_compras->save([
                    'folio' => $id_compra,
                    'id_producto' => $id_producto,
                    'codigo' => $producto['codigo'],
                    'nombre' => $producto['nombre'],
                    'precio' => $producto['precio_compra'],
                    'cantidad' => $cantidad,
                    'subtotal' => $subtotal,
                    'iva' => $iva,
                    'total' => $total
                 ]);
            }
        } else {
            $error = "No existe el producto";
        }

        $res['datos'] = $this->cargaProductos($id_compra);
        $res['total'] = number_format($this->totalProductos($id_compra), 2, '.', ',');
        $res['subtotal'] = number_format($this->subtotalProductos($id_compra), 2, '.', ',');
        $res['iva'] = number_format($this->ivaProductos($id_compra), 2, '.', ',');
        $res['error'] = $error;
        echo json_encode($res);

    }


    public function cargaProductos($id_compra)
    {
        $resultado = $this->temporal_compras->porCompra($id_compra);
        $fila = '';
        $numFila = 0;

        foreach ($resultado as $row) {
            $numFila++;
            $fila .= "<tr id='fila".$numFila."'>";
            $fila .= "<td>".$numFila."</td>";
            $fila .= "<td>".$row['codigo']."</td>";
            $fila .= "<td>".$row['nombre']."</td>";
            $fila .= "<td>".$row['precio']."</td>";
            $fila .= "<td class='text-center h5'> &nbsp;&nbsp;&nbsp;&nbsp;
                            <a onclick=\"eliminaProducto(". $row['id_producto'] . ", '" . $id_compra . "')\"  class='btn btn-outline-danger borrar' id='product_id'><i class='fa fa-minus' aria-hidden='true'></i></a>&nbsp;&nbsp;&nbsp;&nbsp;".$row['cantidad']."&nbsp;&nbsp;&nbsp;&nbsp;
                            <a onclick=\"addProducto(". $row['id_producto'] . ", '" . $id_compra . "')\"  class='btn btn-outline-success add' id='product_id'><i class='fa fa-plus' aria-hidden='true'></i></a></td>";
            $fila .= "<td>".$row['subtotal']."</td>";
            $fila .= "<td>".$row['iva']."</td>";
            $fila .= "<td>".$row['total']."</td>";

            $fila .= "</tr>";
        }
        return $fila;
    }


    public function totalProductos($id_compra)
    {
        $resultado = $this->temporal_compras->porCompra($id_compra);
        $total = 0;

        foreach ($resultado as $row) {
            $total += $row['total'];

        }
        return $total;
    }

    public function subtotalProductos($id_compra)
    {
        $resultado = $this->temporal_compras->porCompra($id_compra);
        $subtotal = 0;

        foreach ($resultado as $row) {
            $subtotal += $row['subtotal'];

        }
        return $subtotal;
    }

    public function ivaProductos($id_compra)
    {
        $resultado = $this->temporal_compras->porCompra($id_compra);
        $iva = 0;

        foreach ($resultado as $row) {
            $iva += $row['iva'];

        }
        return $iva;
    }

    public function eliminar($id_producto, $id_compra)
    {
        $datosExiste = $this->temporal_compras->porIdProductoCompra($id_producto, $id_compra);

        if ($datosExiste) {
            if ($datosExiste->cantidad > 1) {
                $cantidad = $datosExiste->cantidad -1;
                $total = $cantidad * $datosExiste->precio;
                $iva = $total * 0.16;
                $subtotal = $total - $iva;


                $this->temporal_compras->actualizarProductoCompra($id_producto, $id_compra, $cantidad, $subtotal, $iva, $total);
            } else {
                $this->temporal_compras->eliminarProductoCompra($id_producto, $id_compra);
            }
        }

        $res['datos'] = $this->cargaProductos($id_compra);
        $res['total'] = number_format($this->totalProductos($id_compra), 2, '.', ',');
        $res['subtotal'] = number_format($this->subtotalProductos($id_compra), 2, '.', ',');
        $res['iva'] = number_format($this->ivaProductos($id_compra), 2, '.', ',');
        $res['error'] = '';
        echo json_encode($res);
    }

    public function agregarP($id_producto, $id_compra)
    {
        $datosExiste = $this->temporal_compras->porIdProductoCompra($id_producto, $id_compra);

        if ($datosExiste) {
            if ($datosExiste->cantidad >  0) {
                $cantidad = $datosExiste->cantidad +1;
                $total = $cantidad * $datosExiste->precio;
                $iva = $total * 0.16;
                $subtotal = $total - $iva;

                $this->temporal_compras->actualizarProductoCompra($id_producto, $id_compra, $cantidad, $subtotal, $iva, $total);
            } else {
                $this->temporal_compras->eliminarProductoCompra($id_producto, $id_compra);
            }
        }

        $res['datos'] = $this->cargaProductos($id_compra);
        $res['total'] = number_format($this->totalProductos($id_compra), 2, '.', ',');
        $res['subtotal'] = number_format($this->subtotalProductos($id_compra), 2, '.', ',');
        $res['iva'] = number_format($this->ivaProductos($id_compra), 2, '.', ',');
        $res['error'] = '';
        echo json_encode($res);
    }


}

?>
