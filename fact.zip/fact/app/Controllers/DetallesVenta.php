<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DetalleVentaModel;

class DetallesVenta extends BaseController
{
    protected $detalles_venta;

    public function __construct()
    {
        $this->detalles_venta = new DetalleVentaModel();
        helper(['form']);
    }

    public function index($activo = 1)
    {
        $detalles_venta = $this->detalles_venta->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Detalles venta', 'datos' => $detalles_venta];

        echo view('header');
        echo view('detallesVenta/detallesVenta', $data);
        echo view('footer');
    }

   
    public function eliminados($activo = 0)
    {
        $detalles_venta = $this->detalles_venta->where('activo',$activo)->findAll();
        $data = ['titulo' => ' Ventas eliminadas', 'datos' => $detalles_venta];

        echo view('header');
        echo view('detallesVenta/eliminados', $data);
        echo view('footer');
    }

     public function eliminar($id_detalle_venta)
    {
        $this->detalles_venta->update($id_detalle_venta, ['activo' => 0]);
        return redirect()->to(base_url().'/detallesVenta');
    }

    public function reingresar($id_detalle_venta)
    {
        $this->detalles_venta->update($id_detalle_venta, ['activo' => 1]);
        return redirect()->to(base_url().'/detallesVenta');
    }

    public function obtener($id_detalle_venta){
      $this->select('detalle_venta.*, c.diagnostico AS diagnostico , c.receta AS receta, c.fecha_alta AS fecha_consulta, c.id_consulta AS id_consulta');
      $this->join('configuracion AS c', 'configuracion.id_configuracion = c.id_configuracion');
      $this->where('c.id_configuracion', $id_configuracion);
      $this->orderBy('configuracion.id_configuracion', 'DESC');
      $datos = $this->findAll();
      //print_r($this->GetLastQuery());
      return $datos;


      $nombre = $this->configuracion->where('nombre', 'tienda_nombre')->first();
    }

    public function peticion()
    {
      // code...

        $detalles_venta = $this->detalles_venta->findAll();
        return  json_encode($detalles_venta);
    }



}

?>
