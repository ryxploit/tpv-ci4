<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DetalleVentaModel;

class DetallesVenta extends BaseController
{
    protected $detalles_venta;

    public function __construct()
    {
        $this->detalles_venta = new DetalleVentaModel();
        helper(['form']);
    }

    public function index($fecha_alta = true)
    {
        $detalles_venta = $this->detalles_venta->findAll();
        $data = ['titulo' => 'Detalles venta', 'datos' => $detalles_venta];

        echo view('header');
        echo view('detallesVenta/detallesVenta', $data);
        echo view('footer');
    }

    public function peticion()
    {
      // code...

        $detalles_venta = $this->detalles_venta->findAll();
        return  json_encode($detalles_venta);
    }



}

?>
