<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Tables</li>
      <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
    </ul>
  </div>
  <?php if(isset($validation)) { ?>
      <div class="alert alert-danger">
        <?php echo $validation->listErrors(); ?>
      </div>
  <?php } ?>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
            <form action="<?php echo base_url(); ?>/unidades/actualizar" method="POST" autocomplete="off">

            <input type="hidden" value="<?php echo $datos['id_unidades']; ?>" name="id_unidades"/>
            
                <div class="form-group">
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <label for="">Nombre</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" type="text" autofocus require value="<?php echo $datos['nombre']; ?>">
                        </div>

                        <div class="col-12 col-sm-6">
                            <label for="">Nombre corto</label>
                            <input type="text" class="form-control" id="nombre_corto" name="nombre_corto" type="text" require value="<?php echo $datos['nombre_corto']; ?>">
                        </div>
                    </div>
                </div>
                <a href="<?php echo base_url(); ?>/unidades" class="btn btn-primary">Regresar</a>
                <button type="submit" class="btn btn-success">Guardar</button>
            </form>
        </div>
      </div>
    </div>
  </div>
</main>
