<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>

      <div>
        <p>
          <a href="<?php echo base_url();?>/limpieza/nuevo" class="btn btn-info">Agregar</a>
          <a href="<?php echo base_url();?>/limpieza/eliminados" class="btn btn-warning">Eliminados</a>
        </p>
      </div>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item active"><a href="#">Articulos de limpieza</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
          <div class="table-responsive">
            <table class="table table-hover table-bordered" id="sampleTable">
              <thead>
                <tr>

                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Precio</th>
                  <th>Existencia</th>
                  <th class="text-center">Editar</th>
                  <th class="text-center">Eliminar</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach($datos as $dato) { ?>
                <tr>

                  <td><?php echo $dato['codigo']; ?></td>
                  <td><?php echo $dato['nombre']; ?></td>
                  <td><?php echo $dato['precio_venta']; ?></td>
                  <td><?php echo $dato['existencias']; ?></td>
                  <td class="text-center"><a href="<?php echo base_url(). '/limpieza/editar/'. $dato['id_limpieza']; ?>" class="btn btn-warning"><i class="fa fa-edit"></i></a></td>
                  <td class="text-center"><a href="#" data-href="<?php echo base_url(). '/limpieza/eliminar/'. $dato['id_limpieza']; ?>" 
                  data-toggle="modal" data-target="#modalconfirma" title="Eliminar registro" class="btn btn-danger"><i class="fa fa-trash"></i></a></td>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>



<!-- Modal -->
<div class="modal fade" id="modalconfirma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-top" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar producto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ¿Quieres eliminar el registro?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ligth" data-dismiss="modal">Cancelar</button>
        <a class="btn btn-danger btn-ok">Aceptar</a>
      </div>
    </div>
  </div>
</div>
