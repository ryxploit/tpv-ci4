<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>

      <div>
        <p>
          <a href="<?php echo base_url();?>/compras" class="btn btn-warning"> Ventas eliminadas</a>
        </p>
      </div>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item active"><a href="#">Ventas eliminadas</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
          <div class="table-responsive">
            <table class="table table-hover table-bordered" id="sampleTable">
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Folio</th>
                  <th>Total</th>
                  <th>Fecha</th>
                  <th>Eliminar</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach($ventas as $venta) { ?>
                <tr>
                  <td><?php echo $venta['id_venta']; ?></td>
                  <td><?php echo $venta['folio']; ?></td>
                  <td><?php echo $venta['total']; ?></td>
                  <td><?php echo $venta['fecha_alta']; ?></td>
                  <td class="text-center"><a href="#" data-href="<?php echo base_url(). '/ventas/reingresar/'. $venta['id_venta']; ?>"
                  data-toggle="modal" data-target="#modalconfirma" title="Reingresar registro" class="btn btn-danger"><i class="fa fa-trash"></i></a></td>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<!-- Modal -->
<div class="modal fade" id="modalconfirma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-top" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Reingresar Unidad</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ¿Quieres reingresar el registro?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ligth" data-dismiss="modal">Cancelar</button>
        <a class="btn btn-danger btn-ok">Aceptar</a>
      </div>
    </div>
  </div>
</div>
