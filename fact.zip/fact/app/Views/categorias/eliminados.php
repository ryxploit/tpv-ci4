<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>

      <div>
        <p>
          <a href="<?php echo base_url();?>/categorias" class="btn btn-warning">Unidades</a>
        </p>
      </div>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Tables</li>
      <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
          <div class="table-responsive">
            <table class="table table-hover table-bordered" id="sampleTable">
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Nombre</th>
                  <th>Reingresar</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach($datos as $dato) { ?>
                <tr>
                  <td><?php echo $dato['id_categoria']; ?></td>
                  <td><?php echo $dato['nombre']; ?></td>
                  <td><a href="<?php echo base_url(). '/categorias/reingresar/'. $dato['id_categoria']; ?>"><i class="fa fa-arrow-circle-up"></i></a></td>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>
