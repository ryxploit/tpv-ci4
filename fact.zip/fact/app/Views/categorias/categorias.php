<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>

      <div>
        <p>
          <a href="<?php echo base_url();?>/categorias/nuevo" class="btn btn-info">Agregar</a>
          <a href="<?php echo base_url();?>/categorias/eliminados" class="btn btn-warning">Eliminados</a>
        </p>
      </div>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item active"><a href="#">Categorias</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
          <div class="table-responsive">
            <table class="table table-hover table-bordered" id="sampleTable">
              <thead>
                <tr>

                  <th>Nombre</th>
                  <th class="text-center">Modificar</th>
                  <th class="text-center">Eliminar</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach($datos as $dato) { ?>
                <tr>

                  <td><?php echo $dato['nombre']; ?></td>
                  <td class="text-center"><a href="<?php echo base_url(). '/categorias/editar/'. $dato['id_categoria']; ?>" class="btn btn-warning"><i class="fa fa-edit"></i></a></td>
                  <td class="text-center"><a href="<?php echo base_url(). '/categorias/eliminar/'. $dato['id_categoria']; ?>"" class="btn btn-danger"><i class="fa fa-trash"></i></a></td>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>
