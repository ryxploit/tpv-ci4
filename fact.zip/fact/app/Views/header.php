<?php

$user_session = session();

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title>facturaSin</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/css/main.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/js/jquery-ui/jquery-ui.min.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/css/all.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/css/dataTables.dateTime.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/yadcf/0.9.4-beta.12/jquery.dataTables.yadcf.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous" />




    <!-- <script src="<?php echo base_url(); ?>/js/jquery-3.5.1.min.js"></script> -->
    <!-- jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/jquery-ui/external/jquery/jquery.js"></script>
    <script src="<?php echo base_url(); ?>/js/jquery-ui/jquery-ui.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/dataTables.dateTime.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/jquery.dataTables.min.js"></script>
    <script src="//cdn.datatables.net/plug-ins/1.10.22/filtering/row-based/range_dates.js" charset="utf-8"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/yadcf/0.9.4-beta.12/jquery.dataTables.yadcf.min.js" charset="utf-8"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.js" charset="utf-8"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>


</head>

<body class="app sidebar-mini">
    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="<?php echo base_url(); ?>/ventas/venta/">MEI</a>
        <!-- Sidebar toggle button--><div class="toggle"><i class="fas fa-bars app-sidebar__toggle" data-toggle="sidebar"></i></div>
        <!-- Navbar Right Menu-->
        <ul class="app-nav">
            <!-- User Menu-->
            <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><?php echo $user_session->nombre; ?><i class="fa fa-user fa-lg"></i></a>
                <ul class="dropdown-menu settings-menu dropdown-menu-right">
                    <li><a class="dropdown-item" href="<?php echo base_url(); ?>/usuarios/logout"><i  class="fa fa-sign-out fa-lg"></i>Cerrar sesion</a></li>
                </ul>
            </li>
        </ul>
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">

        <ul class="app-menu">

            <li><a class="app-menu__item treeview-item" href="<?php echo base_url(); ?>/ventas/venta/"><i class="icon fa fa-cash-register"></i>Caja</a></li>
            <li><a class="app-menu__item treeview-item" aria-label="Close" href="<?php echo base_url(); ?>/productos/"><i class="icon fa fa-box-open"></i>Articulos</a></li>

            <li><a class="app-menu__item treeview-item" aria-label="Close" href="<?php echo base_url(); ?>/limpieza/"><i class="icon fa fa-hand-sparkles"></i>Limpieza</a></li>

            <li><a class="app-menu__item treeview-item" href="<?php echo base_url(); ?>/unidades/"><i class="icon fa fa-balance-scale"></i>Unidades</a></li>



            <li><a class="app-menu__item treeview-item" href="<?php echo base_url(); ?>/categorias/"><i class="icon fa fa-star"></i>Categorias</a></li>

         <!--<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-truck"></i><span class="app-menu__label">Compras</span><i class="treeview-indicator fa fa-angle-right"></i></a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="<?php echo base_url(); ?>/compras/nuevo"><i class="icon fa fa-circle-o"></i>Nueva compra</a></li>
                    <li><a class="treeview-item" href="<?php echo base_url(); ?>/compras/"><i class="icon fa fa-circle-o"></i>Compras</a></li>
                </ul>
            </li>-->

            <li><a class="app-menu__item treeview-item" href="<?php echo base_url(); ?>/clientes/"><i class="icon fa fa-hospital-user"></i>Pacientes</a></li>
            <li><a class="app-menu__item treeview-item" href="<?php echo base_url(); ?>/ventas/detalle_venta"><i class="icon fa fa-search-dollar"></i>Ventas</a></li>
            <li><a class="app-menu__item treeview-item" href="<?php echo base_url(); ?>/cirugias/"><i class="icon fa fa-user-md"></i>Cirugias</a></li>

           <!--  <li><a class="app-menu__item treeview-item" href="<?php echo base_url(); ?>/clientes/"><i class="icon fa fa-users"></i>Clientes</a></li>

            <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-truck"></i><span class="app-menu__label">Compras</span><i class="treeview-indicator fa fa-angle-right"></i></a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="<?php echo base_url(); ?>/compras/nuevo"><i class="icon fa fa-circle-o"></i>Nueva compra</a></li>
                    <li><a class="treeview-item" href="<?php echo base_url(); ?>/compras/"><i class="icon fa fa-circle-o"></i>Compras</a></li>
                </ul>
            </li>

            <li><a class="app-menu__item treeview-item" href="<?php echo base_url(); ?>/cajas/"><i class="icon fa fa-users"></i>Cajas</a></li>
            <li><a class="app-menu__item treeview-item" href="<?php echo base_url(); ?>/roles/"><i class="icon fa fa-users"></i>Roles</a></li>

            <li><a class="app-menu__item treeview-item" href="<?php echo base_url(); ?>/ventas/venta/"><i class="icon fa fa-cash-register"></i>Caja</a></li>

            <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-wrench"></i><span class="app-menu__label">Administracion</span><i class="treeview-indicator fa fa-angle-right"></i></a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="<?php echo base_url(); ?>/configuracion/"><i class="icon fa fa-circle-o"></i>Configuracion</a></li>
                    <li><a class="treeview-item" href="<?php echo base_url(); ?>/usuarios/"><i class="icon fa fa-circle-o"></i>Usuarios</a></li>
                </ul>
            </li> -->
        </ul>
    </aside>
