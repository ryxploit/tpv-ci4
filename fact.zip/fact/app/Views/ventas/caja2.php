<?php
  $idVentaTmp = uniqid();
 ?>

<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list">Ventas </i></h1>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item active"><a href="#">Ventas</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
            <form method="POST" id="form_venta" name="form_venta" action="<?php echo base_url(); ?>/ventas/guarda" autocomplete="off">
              <!--  <div class="form-group">

                    <div class="row">

                      <input type="hidden" id="id_venta" name="id_venta" value="<?php echo $idVentaTmp; ?>" />

                        <div class="col-12 col-sm-6">
                          <label for="">Cliente:</label>
                            <input type="hidden" id="id_cliente" name="id_cliente" value="1" />
                            <input type="text" id="cliente" class="form-control" name="cliente" laceholder="Escribe el nombre del cliente"value="Publico en general" onkeyup="" autocomplete="off" required />
                        </div>

                        <div class="col-12 col-sm-6">
                            <label for="">Forma de pago:</label>
                            <select name="forma_pago" id="forma_pago" class="form-control" required>
                              <option value="001">Efectivo</option>
                              <option value="002">Tarjeta</option>
                              <option value="003">Tranferencia</option>
                            </select>
                        </div>
                    </div>

                </div>-->

                <input type="hidden" id="id_venta" name="id_venta" value="<?php echo $idVentaTmp; ?>" />
                <div class="form-group">
                    <div class="row">
                      <div class="container">
                        <div class="col-12 col-sm-12">
                            <input type="hidden" id="id_producto" name="id_producto" />
                            <label for="">Codigo de barras </label>
                            <input type="text" class="form-control" id="codigo" name="codigo" placeholder="Escribe el codigo y presiona enter" onkeyup="agregarProducto(event, this.value, 1, <?php echo $idVentaTmp; ?>);" autofocus />
                        </div>
                      </div>

                        <div class="col-sm-2">
                          <label for="codigo" id="resultado_error" style="color: red"></label>
                        </div>


                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                      <div class="col-12 col-sm-4">
                        <label for="" style="font-weight: bold; font-size:30px; text-align: center;">SubTotal $</label>
                        <input type="text" id="Subtotal" name="Subtotal" size="7" readonly="true" value="0.00" style="font-weight: bold; font-size:30px; text-align: center;" />
                      </div>
                      <div class="col-12 col-sm-4">
                        <label for="" style="font-weight: bold; font-size:30px; text-align: center;">IVA $</label>
                        <input type="text" id="iva" name="iva" size="7" readonly="true" value="0.00" style="font-weight: bold; font-size:30px; text-align: center;" />
                      </div>

                      <div class="col-12 col-sm-4">
                        <label for="" style="font-weight: bold; font-size:30px; text-align: center;">Total $</label>
                        <input type="text" id="total" name="total" size="7" readonly="true" value="0.00" style="font-weight: bold; font-size:30px; text-align: center;" />
                      </div>
                    </div>
                </div>



                <div class="form-group">
                  <button data-toggle="modal" data-target="#modalconfirma" type="button" class="btn btn-success">Cobrar</button>
                </div>


                <div class="row">
                  <div class="col-md-12">
                    <div class="tile">
                      <div class="tile-body">
                        <div class="table-responsive">
                          <table class="table table-hover table-bordered tablaProductos" id="tablaProductos">
                            <thead class="thead-dark">
                              <tr>
                                <th>#</th>
                                <th>Codigo</th>
                                <th>Nombre</th>
                                <th>Precio</th>
                                <th>Cantidad</th>
                                <th>Total</th>
                                <th width="1%"></th>
                              </tr>
                            </thead>
                            <tbody>

                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

            </form>
        </div>
      </div>
    </div>
  </div>
</main>


<!-- Modal -->
<div class="modal fade" id="modalconfirma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Venta</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
            <div class="row">
              <div class="col-12 col-sm-4">
                <label for="" style="font-weight: bold; font-size:30px; text-align: center;">Total $</label>
                <input type="text" id="total" name="total" size="7" readonly="true" value="0.00" style="font-weight: bold; font-size:30px; text-align: center;" />
              </div>
              <div class="col-12 col-sm-4">
                <label for="" style="font-weight: bold; font-size:30px; text-align: center;">Paga con $</label>
                <input type="text" id="Subtotal" name="Subtotal" size="7" readonly="true" value="0.00" style="font-weight: bold; font-size:30px; text-align: center;" />
              </div>
              <div class="col-12 col-sm-4">
                <label for="" style="font-weight: bold; font-size:30px; text-align: center;">Cambio $</label>
                <input type="text" id="iva" name="iva" size="7" readonly="true" value="0.00" style="font-weight: bold; font-size:30px; text-align: center;" />
              </div>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ligth" data-dismiss="modal">Cancelar</button>
        <a id="completa_venta" name="completa_venta" class="btn btn-success">Aceptar</a>
      </div>
    </div>
  </div>
</div>


<script>
  $(function(){
    $("#cliente").autocomplete({
      source: "<?php echo base_url(); ?>/clientes/autocompleteData",
      minLength: 3,
      select: function (event, ui){
        event.preventDefault();
        $("#id_cliente").val(ui.item.id);
        $("#cliente").val(ui.item.value);
      }
    });
  });

  $(function(){
    $("#codigo").autocomplete({
      source: "<?php echo base_url(); ?>/productos/autocompleteData",
      minLength: 3,
      select: function (event, ui){
        event.preventDefault();
        $("#codigo").val(ui.item.value);
        setTimeout(
          function(){
            e = jQuery.Event("keypress");
            e.which = 13;
            agregarProducto(e, ui.item.id, 1, '<?php echo $idVentaTmp; ?>');
          }
        )
      }
    });
  });

  function agregarProducto(e, id_producto, cantidad, id_venta){

    let enterKey = 13;

    if (id_producto != '') {
      if (e.which == enterKey) {
        if (id_producto != null && id_producto != 0 && cantidad > 0) {
                $.ajax({

                url: '<?php echo base_url(); ?>/TemporalCompras/inserta/' + id_producto + "/" + cantidad + "/" + id_venta,

                success: function(resultado){
                  if (resultado == 0) {

                  } else {

                    var resultado = JSON.parse(resultado);
                var  sub =  $("#total").val(resultado.total );

              var  iva =  $("#iva").val(resultado.total * 0.16);
                  console.log( parseFloat($("#total").val( )) + parseFloat($("#iva").val()) + ".00");
                 $("#Subtotal").val(parseFloat($("#total").val( )) - parseFloat($("#iva").val()) );
                    if (resultado.error == '') {
                      $("#tablaProductos tbody").empty();
                      $("#tablaProductos tbody").append(resultado.datos);
                    //  $("#total").val();
                      $("#id_producto").val('');
                      $("#codigo").val('');
                      $("#nombre").val('');
                      $("#cantidad").val('');
                      $("#precio_compra").val('');
                      $("#subtotal").val('');
                    }
                  }
                }
              });
        }
      }
    }
  }

  function eliminaProducto(id_producto, id_venta){

    $.ajax({
      url: '<?php echo base_url(); ?>/TemporalCompras/eliminar/' + id_producto + "/" + id_venta,
      success: function(resultado){
        if (resultado == 0) {
          $(tagCodigo).val('');
        } else {

          var resultado = JSON.parse(resultado);

            $("#tablaProductos tbody").empty();
            $("#tablaProductos tbody").append(resultado.datos);
            $("#total").val(resultado.total);

        }
      }
    });
  }

  $(function(){
    $("#completa_venta").click(function(){

      let nFilas = $("#tablaProductos tr").length;
      if(nFilas < 2) {
        alert("debe agregar un producto");
      } else {
        $("#form_venta").submit();
      }
    });
  });
</script>
