<?php 
  $id_compra = uniqid();
 ?>

<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list">Compras </i></h1>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Tables</li>
      <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
            <form method="POST" id="form_compra" name="form_compra" action="<?php echo base_url(); ?>/compras/guarda" autocomplete="off">
                <div class="form-group">
                    <div class="row">
                        <div class="col-12 col-sm-4">
                            <input type="hidden" id="id_producto" name="id_producto" />
                            <input type="hidden" id="id_compra" name="id_compra" value="<?php echo $id_compra; ?>"/>
                            <label for="">Codigo</label> 
                            <input type="text" class="form-control" id="codigo" name="codigo" placeholder="Escribe el codigo y presiona enter" onkeyup="buscarProducto(event, this, this.value)" autofocus >
                            <label for="codigo" id="resultado_error" style="color: red"></label>
                        </div>

                        <div class="col-12 col-sm-4">
                            <label for="">Nombre del producto</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" disabled />
                        </div>

                        <div class="col-12 col-sm-4">
                            <label for="">Cantidad</label>
                            <input type="text" class="form-control" id="cantidad" name="cantidad" />
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-12 col-sm-4">
                            <label for="">Precio de compra</label>
                            <input type="text" class="form-control" id="precio_compra" name="precio_compra" disabled />
                        </div>

                        <div class="col-12 col-sm-4">
                            <label for="">Subtotal</label>
                            <input type="text" class="form-control" id="subtotal" name="subtotal" disabled />
                        </div>

                        <div class="col-12 col-sm-4">
                            <label for=""><br>&nbsp;</label>
                            <button class="btn btn-primary" id="agregar_producto" name="agregar_producto" type="button" onclick="agregarProducto(id_producto.value, cantidad.value, '<?php echo $id_compra; ?>')">Agregar producto</button>
                        </div>
                    </div>
                </div>

                <div class="row">
                  <div class="col-md-12">
                    <div class="tile">
                      <div class="tile-body">
                        <div class="table-responsive">
                          <table class="table table-hover table-bordered tablaProductos" id="tablaProductos">
                            <thead class="thead-dark">
                              <tr>
                                <th>#</th>
                                <th>Codigo</th>
                                <th>Nombre</th>
                                <th>Precio</th>
                                <th>Cantidad</th>
                                <th>Total</th>
                                <th width="1%"></th>
                              </tr>
                            </thead>
                            <tbody>

                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-12 col-sm-6 offset-md-6">
                    <label for="" style="font-weight: bold; font-size:30px; text-align: center;">Total $</label>
                    <input type="text" id="total" name="total" size="7" readonly="true" value="0.00" style="font-weight: bold; font-size:30px; text-align: center;" />
                    <button type="button" id="completa_compra" class="btn btn-success">Completar compra</button>
                  </div>
                </div>
            </form>
        </div>
      </div>
    </div>
  </div>
</main>

<!-- Modal -->
<div class="modal fade" id="modalconfirma" name="modalconfirma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-top" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar producto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ¿Quieres eliminar el registro?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ligth" data-dismiss="modal">Cancelar</button>
        <a class="btn btn-danger btn-ok">Aceptar</a>
      </div>
    </div>
  </div>
</div>


<script>
  $(document).ready(function(){
    $("#completa_compra").click(function(){
      let nFila = $("#tablaProductos tr").length;

      if (nFila < 2) {
        $("#modalconfirma").submit();
      } else {
        $("#form_compra").submit();
      }
    });
  });

  function buscarProducto(e, tagCodigo, codigo){
    var enterKey = 13;

    if (codigo != '') {
        if (e.which == enterKey) {
            $.ajax({
              url: '<?php echo base_url(); ?>/productos/buscarPorCodigo/' + codigo,
              dataType: 'json',
              success: function(resultado){
                if (resultado == 0) {
                    $(tagCodigo).val('');
                } else {

                  $("#resultado_error").html(resultado.error);

                  if (resultado.existe) {
                    $("#id_producto").val(resultado.datos.id_producto);
                    $("#nombre").val(resultado.datos.nombre);
                    $("#cantidad").val(1);
                    $("#precio_compra").val(resultado.datos.precio_compra);
                    $("#subtotal").val(resultado.datos.precio_compra);
                    $("#cantidad").focus();
                  } else {
                    $("#id_producto").val('');
                    $("#nombre").val('');
                    $("#cantidad").val('');
                    $("#precio_compra").val('');
                    $("#subtotal").val('');
                  }
                }
              }
            });
        }
    }
  };


  function agregarProducto(id_producto, cantidad, id_compra){

    if (id_producto != null && id_producto != 0 && cantidad > 0) {
            $.ajax({
              
            url: '<?php echo base_url(); ?>/TemporalCompras/inserta/' + id_producto + "/" + cantidad + "/" + id_compra,
            
            success: function(resultado){
              if (resultado == 0) {
                  
              } else {

                var resultado = JSON.parse(resultado);

                if (resultado.error == '') {
                  $("#tablaProductos tbody").empty();
                  $("#tablaProductos tbody").append(resultado.datos);
                  $("#total").val(resultado.total);
                  $("#id_producto").val('');
                  $("#codigo").val('');
                  $("#nombre").val('');
                  $("#cantidad").val('');
                  $("#precio_compra").val('');
                  $("#subtotal").val('');
                }
              }
            }
          });
    }
  }


  function eliminaProducto(id_producto, id_compra){

      $.ajax({
        url: '<?php echo base_url(); ?>/TemporalCompras/eliminar/' + id_producto + "/" + id_compra,
        success: function(resultado){
          if (resultado == 0) {
            $(tagCodigo).val('');
          } else {

            var resultado = JSON.parse(resultado);

              $("#tablaProductos tbody").empty();
              $("#tablaProductos tbody").append(resultado.datos);
              $("#total").val(resultado.total);

          }
        }
      });
  } 
</script>