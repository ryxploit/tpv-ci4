<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>
      <div>
        <p>
          <a href="<?php echo base_url();?>/detallesVenta/eliminados" class="btn btn-warning">Ventas Eliminados</a>
        </p>
      </div>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item active"><a href="#"> Ventas</a></li>
    </ul>
  </div>
  <div class="row" style="text-align: center;">
    <div class="col-md-4">

    </div>
    <div class="col-md-4">
      <div class="card" style="border-color: red">
        <div class="card-header">
          <p class="h3"> <strong>Total de venta:</strong> </p>
        </div>
        <div class="card-body">
            <p class="h4 mr-4" id="resultado_total"></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card">

      </div>
    </div>
  </div>

  <br>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
          <div class="table-responsive">

            <table  id="example" class="display nowrap table table-hover table-bordered">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Fecha inicio</th>
                  <th>Fecha fin</th>
                  <th>Subotal</th>
                  <th>Iva</th>
                  <th>Total</th>
                  <th>Eliminar</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach($datos as $dato) { ?>
                <tr>
                  <td><?php echo $dato['nombre']; ?></td>
                  <td><?php echo $dato['fecha_alta']; ?></td>
                  <td><?php echo $dato['fecha_alta']; ?></td>
                  <td class="subtotal"><?php echo $dato['subtotal']; ?></td>
                  <td class="iva"><?php echo $dato['iva']; ?></td>
                  <td class="total"><?php echo $dato['total']; ?></td>
                  <td class="text-center"><a href="#" data-href="<?php echo base_url(). '/detallesVenta/eliminar/'. $dato['id_detalle_venta']; ?>"
                  data-toggle="modal" data-target="#modalconfirma" title="Eliminar registro" class="btn btn-danger"><i class="fa fa-trash"></i></a></td>
                </tr>
              <?php } ?>
              </tbody>
              <tfoot>
                <th >Nombre</th>
                <th id="position">Fecha inicio</th>
                <th id="office">Fecha fin</th>
                <th >Subtotal</th>
                <th >Iva</th>
                <th >Total</th>
                <th>Eliminar</th>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<!-- Modal -->
<div class="modal fade" id="modalconfirma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-top" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar venta</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="text-align: center;">
        ¿Quieres eliminar el registro?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ligth" data-dismiss="modal">Cancelar</button>
        <a class="btn btn-danger btn-ok">Aceptar</a>
      </div>
    </div>
  </div>
</div>


<script type="text/javascript">

$(document).ready( function () {
  $.fn.dataTable.ext.search.push(
    function( settings, searchData, index, rowData, counter ) {
      var position = $( "#position option:selected" ).text();
      var office = $( "#office option:selected" ).text();

      // Display the row if both inputs are empty
      if (position.length ===0 && office.length === 0) {
        return true;
      }

      // Display row if position matches position selection
      hasPosition = true;

      if (position !== searchData[1]) {
        hasPosition = false; //Doesn't match - don't display
      }

      // Display the row if office matches the office selection
      hasOffice = true;

      if (office !== searchData[2]) {
        hasOffice = false; //Doesn't match - don't display
      }

      // If either position or office matched then display the row
      return true ? hasPosition || hasOffice : false;
    });

  $('#example').DataTable( {
        initComplete: function () {
            this.api().columns([1,2]).every( function () {
                var column = this;
                var select = $('<select class="form-control" style="border-color: black" id="range"><option selected value="fecha">Mostrar todos los dias</option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'keyup change', function () {
                      $('#example').DataTable().draw();
                    } );

                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        }
    } );} );

    var sum=0;
    $('.total').each(function() {
     sum += parseFloat($(this).text().replace(/,/g, ''), 10);
    });
    $('#resultado_total').html("$" + sum.toFixed(2));

    $(document).on('change', '#range', function(event) {
      var sum=0;
    var to =  $("#range option:selected").text()
        if (to == 'Mostrar todos los dias' ) {
          location.reload();
        } else {
          $('.total').each(function() {
           sum += parseFloat($(this).text().replace(/,/g, ''), 10);
          });
          $('#resultado_total').html("$" + sum.toFixed(2));
        }

  });


  $(document).ready(function () {
       $('select').selectize({
         create: true,
           sortField: 'text'
       });
   });

</script>
