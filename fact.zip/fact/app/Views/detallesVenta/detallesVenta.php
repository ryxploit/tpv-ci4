<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item active"><a href="#">Articulos de limpieza</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
          <div class="table-responsive">
            <table border="0" cellspacing="5" cellpadding="5">
                <tbody><tr>
                    <td>Minimum date:</td>
                    <td><input type="text" id="min" name="min"></td>
                </tr>
                <tr>
                    <td>Maximum date:</td>
                    <td><input type="text" id="max" name="max"></td>
                </tr>
            </tbody></table>
            <table  id="example" class="display nowrap">
              <thead>
                <tr>
                  <th>Id_venta</th>
                  <th>Id_producto</th>
                  <th>Nombre</th>
                  <th>Cantidad</th>
                  <th>Precio</th>
                  <th>Fecha_alta</th>
                </tr>
              </thead>

            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>


<script type="text/javascript">
$(document).ready(function(){
  var dataTable = $('#example').DataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    //'searching': false, // Remove default Search Control
    'ajax': {
       'url':'<?php echo base_url(); ?>/DetallesVenta/peticion',
       'data': function(data){
          // Read values
          var fecha_alta = $('#min').val();
        //  var name = $('#max').val();

          // Append to data
          data.min = fecha_alta;
        //  data.min = name;
       }
    },
    'columns': [
       { data: 'id_venta' },
       { data: 'id_producto' },
       { data: 'nombre' },
       { data: 'cantidad' },
       { data: 'fecha_alta' },
    ]
  });

  $('#min').keyup(function(){
    dataTable.draw();
  });

  $('#max').change(function(){
    dataTable.draw();
  });
});


</script>
