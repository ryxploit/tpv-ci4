<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item active"><a href="#">Agregar cirugia</a></li>
    </ul>
  </div>
  <?php if(isset($validation)) { ?>
      <div class="alert alert-danger">
        <?php echo $validation->listErrors(); ?>
      </div>
  <?php } ?>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
            <form action="<?php echo base_url(); ?>/clientes/insertar_cirugia" method="POST" autocomplete="off">
                <div class="form-group">
                    <div class="row">
                      <input type="hidden" name="id_cliente" value="<?php echo $cliente_id; ?>">
                        <div class="col-12 col-sm-6">
                            <label for="">Diagnostico medico</label>
                            <textarea class="form-control" name="diagnostico_medico" id="diagnostico_medico" cols="20" rows="6" value="<?php echo set_value('diagnostico_medico') ?>" required></textarea>
                        </div>
                        <div class="col-12 col-sm-6">
                            <label for="">Cirugia</label>
                            <select class="form-control" name="id_cirugia" id="id_cirugia" required>
                              <option value="">Selecionar cirugia</option>
                              <?php foreach($cirugias as $cirugia) { ?>
                                <option value="<?php echo $cirugia['id_cirugia']; ?>"><?php echo $cirugia['nombre']; ?></option>
                              <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
                <a href="<?php echo base_url(); ?>/clientes" class="btn btn-primary">Regresar</a>
                <button type="submit" class="btn btn-success">Guardar</button>
            </form>
        </div>
      </div>
    </div>
  </div>
</main>
