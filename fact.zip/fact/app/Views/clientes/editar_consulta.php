<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>
      <?php if(isset($validation)) { ?>
      <div class="alert alert-danger">
        <?php echo $validation->listErrors(); ?>
      </div>
  <?php } ?>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item active"><a href="#">Expediente clinico</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
            <form action="" method="" autocomplete="off" id="form_compra" name="form_compra">

              <input type="hidden" id="id_consulta" name="id_consulta" value="<?php echo $consultas['id_consulta']; ?>" />

              <div class="form-group">
                  <div class="row">
                      <div class="col-12 col-sm-6">
                              <label for="">Diagnostico medico</label>
                              <textarea class="form-control" name="diagnostico_medico" id="diagnostico_medico" cols="30" rows="6" required disabled><?php echo $consultas['diagnostico']; ?></textarea>
                      </div>
                      <div class="col-12 col-sm-6">
                            <label for="">Categoria</label>
                            <select class="form-control" name="id_cirugia" id="id_cirugia" required disabled>
                              <option value="">Seleciionar cirugia</option>
                              <?php foreach($cirugias as $cirugia) { ?>
                                <option value="<?php echo $cirugia['id_cirugia']; ?>" <?php if($cirugia['id_cirugia'] == $consultas['id_cirugia']) {
                                  echo 'selected'; } ?>><?php echo $cirugia['nombre']; ?></option>
                              <?php } ?>
                            </select>
                        </div>
                  </div>
              </div>
                <a href="<?php echo base_url(); ?>/clientes" class="btn btn-primary">Regresar</a>
                <a href="<?php echo base_url(). '/clientes/muestraCompraPdf/'. $consultas['id_consulta']; ?>" class="btn btn-primary"><i class="fa fa-file"></i>Imprimir diagnostico</a>
              <div class="on">

              </div>

            </form>
        </div>
      </div>
    </div>
  </div>
</main>

<script type="text/javascript">

function inicio(){
  var valor = $('#id_cirugia option:selected').val();

  if (valor == 1) {
  $('.on').html("  <a href='<?php echo base_url(). '/clientes/muestraReceta1Pdf/'. $consultas['id_consulta']; ?>' class='btn btn-primary receta'><i class='fa fa-file'></i>Imprimir receta</a> ");

}else if (valor == 2) {
  $('.on').html("  <a href='<?php echo base_url(). '/clientes/muestraReceta2Pdf/'. $consultas['id_consulta']; ?>' class='btn btn-primary receta'><i class='fa fa-file'></i>Imprimir receta</a> ");

}else if (valor == 3) {
  $('.on').html("  <a href='<?php echo base_url(). '/clientes/muestraReceta3Pdf/'. $consultas['id_consulta']; ?>' class='btn btn-primary receta'><i class='fa fa-file'></i>Imprimir receta</a> ");

}else if (valor == 4) {
  $('.on').html("  <a href='<?php echo base_url(). '/clientes/muestraReceta4Pdf/'. $consultas['id_consulta']; ?>' class='btn btn-primary receta'><i class='fa fa-file'></i>Imprimir receta</a> ");

}else if (valor == 5) {
  $('.on').html("  <a href='<?php echo base_url(). '/clientes/muestraReceta5Pdf/'. $consultas['id_consulta']; ?>' class='btn btn-primary receta'><i class='fa fa-file'></i>Imprimir receta</a> ");

}else if (valor == 6) {
  $('.on').html("  <a href='<?php echo base_url(). '/clientes/muestraReceta6Pdf/'. $consultas['id_consulta']; ?>' class='btn btn-primary receta'><i class='fa fa-file'></i>Imprimir receta</a> ");

}

}

$(window).on("load", inicio);


</script>
