<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>

      <div>
        <p>
        <?php foreach($datoos as $dato) { ?>
          <a href="<?php echo base_url();?>/clientes/nuevo_consulta/<?php echo $dato['id_cliente']; ?>" class="btn btn-info">Agregar receta</a>
          <a href="<?php echo base_url();?>/clientes/nuevo_cirugia/<?php echo $dato['id_cliente']; ?>" class="btn btn-warning">Agregar Cirugia</a>
        <?php } ?>
        </p>
      </div>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Expendientes</li>

    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
          <div class="table-responsive">
            <table class="table table-hover table-bordered" id="sampleTable">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Cirugia</th>
                  <th>Fecha</th>
                  <th class="text-center">Expediente</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach($datos as $dato) { ?>
                <tr>
                  <td><?php echo $dato['nombre']; ?></td>
                  <td><?php echo $dato['id_cirugia']; ?></td>
                  <td><?php echo $dato['fecha_consulta']; ?></td>
                  <td class="text-center"><a href="<?php echo base_url(). '/clientes/editar_consulta/'. $dato['id_consulta']; ?>" class="btn btn-primary"><i class="fa fa-file-medical-alt"></i></a></td>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>



<!-- Modal -->
<div class="modal fade" id="modalconfirma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-top" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar producto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ¿Quieres eliminar el registro?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ligth" data-dismiss="modal">Cancelar</button>
        <a class="btn btn-danger btn-ok">Aceptar</a>
      </div>
    </div>
  </div>
</div>
