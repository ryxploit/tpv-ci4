<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>
      <?php if(isset($validation)) { ?>
      <div class="alert alert-danger">
        <?php echo $validation->listErrors(); ?>
      </div>
  <?php } ?>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Tables</li>
      <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
            <form action="<?php echo base_url(); ?>/clientes/actualizar" method="POST" autocomplete="off">

              <input type="hidden" id="id_cliente" name="id_cliente" value="<?php echo $cliente['id_cliente']; ?>" />

              <div class="form-group">
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <label for="">Nombre</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" type="text" value="<?php echo $cliente['nombre']; ?>" autofocus required>
                        </div>

                        <div class="col-12 col-sm-6">
                            <label for="">Direccion</label>
                            <input type="text" class="form-control" id="direccion" name="direccion" type="text" value="<?php echo $cliente['direccion']; ?>" required>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <label for="">Telefono</label>
                            <input type="text" class="form-control" id="telefono" name="telefono" type="text" value="<?php echo $cliente['telefono']; ?>" autofocus required>
                        </div>

                        <div class="col-12 col-sm-6">
                            <label for="">Correo</label>
                            <input type="text" class="form-control" id="correo" name="correo" type="text" value="<?php echo $cliente['correo']; ?>" required>
                        </div>
                    </div>
                </div>
                <!-- <div class="form-group">
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <label for="">Receta</label>
                            <textarea class="form-control" name="text_area" id="text_area" cols="30" rows="6" required><?php echo $cliente['text_area']; ?></textarea>
                        </div>
                    </div>
                </div> -->
                <a href="<?php echo base_url(); ?>/clientes" class="btn btn-primary">Regresar</a>
                <button type="submit" class="btn btn-success">Guardar</button>
            </form>
        </div>
      </div>
    </div>
  </div>
</main>
