<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"><?php echo $titulo; ?></i></h1>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Tables</li>
      <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
    </ul>
  </div>
  <?php if(isset($validation)) { ?>
      <div class="alert alert-danger">
        <?php echo $validation->listErrors(); ?>
      </div>
  <?php } ?>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
            <form action="<?php echo base_url(); ?>/usuarios/insertar" method="POST" autocomplete="off">
                <div class="form-group">
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <label for="">Usuario</label>
                            <input type="text" class="form-control" id="usuario" name="usuario" type="text" value="<?php echo set_value('usuario') ?>" autofocus required>
                        </div>

                        <div class="col-12 col-sm-6">
                            <label for="">Nombre</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" type="text" value="<?php echo set_value('nombre') ?>" required>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <label for="">Contraseña</label>
                            <input type="password" class="form-control" id="password" name="password" type="text" value="<?php echo set_value('password') ?>" required>
                        </div>

                        <div class="col-12 col-sm-6">
                            <label for="">Repite contraseña</label>
                            <input type="password" class="form-control" id="repassword" name="repassword" type="text" value="<?php echo set_value('repassword') ?>" required>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <label for="">Cajas</label>
                            <select class="form-control" name="id_caja" id="id_caja" required>
                              <option value="">Seleciionar Unidad</option>
                              <?php foreach($cajas as $caja) { ?>
                                <option value="<?php echo $caja['id_caja']; ?>"><?php echo $caja['nombre']; ?></option>
                              <?php } ?>
                            </select>
                        </div>

                        <div class="col-12 col-sm-6">
                            <label for="">Rol</label>
                            <select class="form-control" name="id_rol" id="id_rol" required>
                              <option value="">Selecionar categoria</option>
                              <?php foreach($roles as $rol) { ?>
                                <option value="<?php echo $rol['id_rol']; ?>"><?php echo $rol['nombre']; ?></option>
                              <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
                <a href="<?php echo base_url(); ?>/usuarios" class="btn btn-primary">Regresar</a>
                <button type="submit" class="btn btn-success">Guardar</button>
            </form>
        </div>
      </div>
    </div>
  </div>
</main>
