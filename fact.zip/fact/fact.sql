-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-03-2021 a las 00:27:55
-- Versión del servidor: 10.4.13-MariaDB
-- Versión de PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `fact`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cajas`
--

CREATE TABLE `cajas` (
  `id_caja` int(11) NOT NULL,
  `numero_caja` varchar(10) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `folio` int(11) NOT NULL,
  `activo` tinyint(4) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cajas`
--

INSERT INTO `cajas` (`id_caja`, `numero_caja`, `nombre`, `folio`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(1, '1', 'caja general', 65, 1, '2021-02-13 07:52:30', '2021-02-13 08:52:30'),
(2, '2', 'admin', 52, 1, '2021-02-13 07:45:27', '2021-02-13 08:45:27'),
(3, '23', 'asas', 21, 1, '2021-02-13 07:52:08', '2021-02-13 08:52:08'),
(4, '1', 'asd', 45, 1, '2021-02-22 21:46:19', '2021-02-17 05:02:34'),
(5, '3', 'sdfd', 65, 1, '2021-02-17 05:03:59', '2021-02-17 05:03:59');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_categoria` smallint(6) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categoria`, `nombre`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(3, 'Desechables', 1, '2021-03-03 21:36:24', '2021-03-03 21:36:24'),
(4, 'Medicamento', 1, '2021-03-03 21:36:52', '2021-03-03 21:36:52'),
(5, 'Limpieza', 1, '2021-03-03 21:52:23', '2021-03-03 21:52:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(50) DEFAULT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `id_consulta` int(11) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nombre`, `direccion`, `telefono`, `correo`, `activo`, `id_consulta`, `fecha_alta`, `fecha_edit`) VALUES
(7, 'Carlos Alonso Avila Osuna', 'Lazaro Cardenas #4002, Col Centro, Mazatlan', '6695465265', 'carlos@gmail.com', 1, 0, '2021-03-03 21:58:51', '2021-03-03 21:58:51');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `id_compra` int(11) NOT NULL,
  `folio` varchar(15) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `configuracion`
--

CREATE TABLE `configuracion` (
  `id_configuracion` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `valor` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `configuracion`
--

INSERT INTO `configuracion` (`id_configuracion`, `nombre`, `valor`) VALUES
(1, 'tienda_nombre', 'CLINICA MEI'),
(2, 'tienda_rfc', '1'),
(3, 'tienda_telefono', '669 136 0639'),
(4, 'tienda_email', '1'),
(5, 'tienda_direccion', 'Rio Panuco 125, Loma de juarez, Reforma 82030 Mazatlan'),
(6, 'ticket_leyenda', '1'),
(7, 'password', '12345');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consultas`
--

CREATE TABLE `consultas` (
  `id_consulta` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `diagnostico` varchar(200) NOT NULL,
  `receta` varchar(200) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `consultas`
--

INSERT INTO `consultas` (`id_consulta`, `id_cliente`, `diagnostico`, `receta`, `fecha_alta`) VALUES
(16, 7, 'Dolor de Cabeza', 'Tomas dos pastillas paracetamol cada 6 horas por 5 dias', '2021-03-03 22:00:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_compra`
--

CREATE TABLE `detalle_compra` (
  `id_detalle_compra` int(11) NOT NULL,
  `id_compra` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_venta`
--

CREATE TABLE `detalle_venta` (
  `id_detalle_venta` int(11) NOT NULL,
  `id_venta` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `fecha_alta` date NOT NULL DEFAULT current_timestamp(),
  `activo` int(11) NOT NULL DEFAULT 1,
  `subtotal` decimal(10,2) NOT NULL,
  `iva` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `detalle_venta`
--

INSERT INTO `detalle_venta` (`id_detalle_venta`, `id_venta`, `id_producto`, `nombre`, `cantidad`, `precio`, `fecha_alta`, `activo`, `subtotal`, `iva`, `total`) VALUES
(35, 28, 4, 'Jeringa', 2, '10.00', '2021-03-05', 1, '16.80', '3.20', '20.00'),
(36, 28, 5, 'Jeringa naranja', 2, '8.00', '2021-03-05', 1, '13.44', '2.56', '16.00'),
(37, 29, 4, 'Jeringa', 2, '10.00', '2021-03-05', 1, '16.80', '3.20', '20.00'),
(38, 29, 5, 'Jeringa naranja', 2, '8.00', '2021-03-05', 1, '13.44', '2.56', '16.00'),
(39, 30, 4, 'Jeringa', 8, '10.00', '2021-03-05', 1, '67.20', '12.80', '80.00'),
(40, 31, 5, 'Jeringa naranja', 1, '8.00', '2021-03-05', 1, '6.72', '1.28', '8.00'),
(41, 32, 5, 'Jeringa naranja', 1, '8.00', '2021-03-05', 1, '6.72', '1.28', '8.00'),
(42, 33, 5, 'Jeringa naranja', 1, '8.00', '2021-03-05', 1, '6.72', '1.28', '8.00'),
(43, 34, 5, 'Jeringa naranja', 1, '8.00', '2021-03-05', 1, '6.72', '1.28', '8.00'),
(44, 35, 5, 'Jeringa naranja', 1, '8.00', '2021-03-05', 1, '6.72', '1.28', '8.00'),
(45, 36, 6, 'Gasas', 1, '8.00', '2021-03-05', 1, '6.72', '1.28', '8.00'),
(46, 37, 6, 'Gasas', 1, '8.00', '2021-03-05', 1, '6.72', '1.28', '8.00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `limpieza`
--

CREATE TABLE `limpieza` (
  `id_limpieza` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `precio_venta` decimal(10,2) DEFAULT NULL,
  `precio_compra` decimal(10,2) NOT NULL DEFAULT 0.00,
  `existencias` int(11) NOT NULL DEFAULT 0,
  `stock_minimo` int(11) NOT NULL DEFAULT 0,
  `inventariable` tinyint(4) NOT NULL,
  `id_unidad` smallint(6) NOT NULL,
  `id_categoria` smallint(6) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `limpieza`
--

INSERT INTO `limpieza` (`id_limpieza`, `codigo`, `nombre`, `precio_venta`, `precio_compra`, `existencias`, `stock_minimo`, `inventariable`, `id_unidad`, `id_categoria`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(2, '02', 'prueba', '50.00', '20.00', 35, 5, 0, 5, 3, 1, '2021-03-05 23:26:03', NULL),
(3, '02', 'asdasdas', NULL, '20.00', 45, 5, 0, 5, 3, 1, '2021-03-05 23:27:05', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `precio_venta` decimal(10,2) NOT NULL,
  `precio_compra` decimal(10,2) NOT NULL DEFAULT 0.00,
  `existencias` int(11) NOT NULL,
  `stock_minimo` int(11) NOT NULL DEFAULT 0,
  `inventariable` tinyint(4) DEFAULT NULL,
  `id_unidad` smallint(6) NOT NULL,
  `id_categoria` smallint(6) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `codigo`, `nombre`, `precio_venta`, `precio_compra`, `existencias`, `stock_minimo`, `inventariable`, `id_unidad`, `id_categoria`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(4, '01', 'Jeringa', '15.00', '10.00', 5, 5, NULL, 4, 3, 1, '2021-03-05 08:17:13', NULL),
(5, '02', 'Jeringa naranja', '10.00', '8.00', 7, 7, NULL, 4, 3, 1, '2021-03-05 08:24:16', NULL),
(6, '03', 'Gasas', '10.00', '8.00', 9, 10, NULL, 5, 3, 1, '2021-03-05 16:44:56', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `activo` tinyint(4) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id_rol`, `nombre`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(1, 'admin2', 1, '2021-02-17 04:22:18', '2021-02-17 05:22:18'),
(2, 'Moderador', 1, '2021-02-17 04:19:56', '2021-02-17 05:19:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `temporal_compra`
--

CREATE TABLE `temporal_compra` (
  `id_temporal` int(11) NOT NULL,
  `folio` varchar(15) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `iva` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `temporal_compra`
--

INSERT INTO `temporal_compra` (`id_temporal`, `folio`, `id_producto`, `codigo`, `nombre`, `cantidad`, `precio`, `subtotal`, `iva`, `total`) VALUES
(221, '6041e9144274b', 4, '01', 'Jeringa', 1, '10.00', '8.40', '1.60', '10.00'),
(227, '6041eab29744a', 5, '02', 'Jeringa naranja', 1, '8.00', '6.72', '1.28', '8.00'),
(228, '6041eaeea25c5', 5, '02', 'Jeringa naranja', 1, '8.00', '6.72', '1.28', '8.00'),
(230, '60425fc45f601', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(232, '6042646c6e139', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(233, '6042650860eb0', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(234, '604265d902ebc', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(235, '6042661e6d521', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(236, '6042682f68f33', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(237, '6042684a954d3', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(238, '604268fd04f05', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(239, '6042696632482', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(240, '604269a6d620c', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(241, '604269a6d620c', 4, '01', 'Jeringa', 1, '10.00', '8.40', '1.60', '10.00'),
(242, '604269f7ebe88', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(243, '60426a5ec509a', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(244, '60426a7f2f9ee', 6, '03', 'Gasas', 2, '8.00', '13.44', '2.56', '16.00'),
(245, '60426a7f2f9ee', 4, '01', 'Jeringa', 1, '10.00', '8.40', '1.60', '10.00'),
(246, '60426a9b334f5', 4, '01', 'Jeringa', 1, '10.00', '8.40', '1.60', '10.00'),
(247, '60426aacec057', 4, '01', 'Jeringa', 2, '10.00', '16.80', '3.20', '20.00'),
(248, '60426b7ea2ab4', 4, '01', 'Jeringa', 1, '10.00', '8.40', '1.60', '10.00'),
(249, '6042775aa51b1', 6, '03', 'Gasas', 1, '8.00', '6.72', '1.28', '8.00'),
(250, '6042775aa51b1', 4, '01', 'Jeringa', 1, '10.00', '8.40', '1.60', '10.00'),
(251, '60427798bb18b', 4, '01', 'Jeringa', 1, '10.00', '8.40', '1.60', '10.00'),
(252, '6042782373316', 4, '01', 'Jeringa', 1, '10.00', '8.40', '1.60', '10.00'),
(253, '60427c923dc79', 4, '01', 'Jeringa', 1, '10.00', '8.40', '1.60', '10.00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `unidades`
--

CREATE TABLE `unidades` (
  `id_unidades` smallint(6) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `nombre_corto` varchar(10) NOT NULL,
  `activo` tinyint(3) NOT NULL DEFAULT 1,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `unidades`
--

INSERT INTO `unidades` (`id_unidades`, `nombre`, `nombre_corto`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(4, 'Pieza', 'pz', 1, '2021-03-03 21:34:57', '2021-03-03 21:34:57'),
(5, 'Caja', 'cj', 1, '2021-03-03 20:35:45', '2021-03-03 21:35:45'),
(6, 'Litro', 'Lt', 1, '2021-03-03 21:51:33', '2021-03-03 21:51:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `password` varchar(130) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `id_caja` int(11) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `activo` int(11) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `usuario`, `password`, `nombre`, `id_caja`, `id_rol`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(1, 'admin', '$2y$10$VEmry7wopuk5QXcKwkxm1OHVEr1hTo9BdQMlDlKKs/BQpA9I9BkDm', 'Administrador', 1, 1, 1, '2021-03-03 20:18:38', '2021-02-12 07:28:55'),
(2, 'asas5', '$2y$10$l7FGxG7c0PwgWGZOVxCyfeuKcqc/NA7sD7r.v1S7F8zv6KTGnb14e', 'asas', 1, 1, 1, '2021-02-12 06:17:45', '2021-02-12 07:17:45'),
(3, 'mario', '$2y$10$VEmry7wopuk5QXcKwkxm1OHVEr1hTo9BdQMlDlKKs/BQpA9I9BkDm', 'MAriol  labrador avila', 1, 1, 1, '2021-02-13 07:29:18', '2021-02-13 08:29:18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id_venta` int(11) NOT NULL,
  `folio` varchar(15) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_usuario` int(11) NOT NULL,
  `id_caja` int(11) NOT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `forma_pago` varchar(5) DEFAULT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id_venta`, `folio`, `total`, `fecha_alta`, `id_usuario`, `id_caja`, `id_cliente`, `forma_pago`, `activo`) VALUES
(28, '6041e8681426c', '36.00', '2021-03-05 09:14:57', 1, 1, NULL, NULL, 1),
(29, '6041e8c3e51cc', '36.00', '2021-03-05 09:16:23', 1, 1, NULL, NULL, 1),
(30, '6041e8f25b6d0', '80.00', '2021-03-05 09:17:13', 1, 1, NULL, NULL, 1),
(31, '6041e99fdd09f', '8.00', '2021-03-05 09:19:54', 1, 1, NULL, NULL, 1),
(32, '6041e9ad59259', '8.00', '2021-03-05 09:20:06', 1, 1, NULL, NULL, 1),
(33, '6041e9d02eb3a', '8.00', '2021-03-05 09:20:39', 1, 1, NULL, NULL, 1),
(34, '6041e9d9e2c4f', '8.00', '2021-03-05 09:20:54', 1, 1, NULL, NULL, 1),
(35, '6041eaa323d15', '8.00', '2021-03-05 09:24:16', 1, 1, NULL, NULL, 1),
(36, '60425fa75c3a3', '8.00', '2021-03-05 17:43:38', 1, 1, NULL, NULL, 1),
(37, '60425ff921ca6', '8.00', '2021-03-05 17:44:56', 1, 1, NULL, NULL, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cajas`
--
ALTER TABLE `cajas`
  ADD PRIMARY KEY (`id_caja`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id_compra`),
  ADD KEY `fk_compras_usuario` (`id_usuario`);

--
-- Indices de la tabla `configuracion`
--
ALTER TABLE `configuracion`
  ADD PRIMARY KEY (`id_configuracion`);

--
-- Indices de la tabla `consultas`
--
ALTER TABLE `consultas`
  ADD PRIMARY KEY (`id_consulta`);

--
-- Indices de la tabla `detalle_compra`
--
ALTER TABLE `detalle_compra`
  ADD PRIMARY KEY (`id_detalle_compra`),
  ADD KEY `fk_detalle_compra` (`id_compra`),
  ADD KEY `fk_detalle_producto` (`id_producto`);

--
-- Indices de la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  ADD PRIMARY KEY (`id_detalle_venta`);

--
-- Indices de la tabla `limpieza`
--
ALTER TABLE `limpieza`
  ADD PRIMARY KEY (`id_limpieza`),
  ADD KEY `fk_producto_categoriap` (`id_categoria`),
  ADD KEY `fk_producto_unidadp` (`id_unidad`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD KEY `fk_producto_unidad` (`id_unidad`),
  ADD KEY `fk_producto_categoria` (`id_categoria`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `temporal_compra`
--
ALTER TABLE `temporal_compra`
  ADD PRIMARY KEY (`id_temporal`);

--
-- Indices de la tabla `unidades`
--
ALTER TABLE `unidades`
  ADD PRIMARY KEY (`id_unidades`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `id_caja` (`id_caja`),
  ADD KEY `id_rol` (`id_rol`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id_venta`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cajas`
--
ALTER TABLE `cajas`
  MODIFY `id_caja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id_categoria` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `id_compra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `configuracion`
--
ALTER TABLE `configuracion`
  MODIFY `id_configuracion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `consultas`
--
ALTER TABLE `consultas`
  MODIFY `id_consulta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `detalle_compra`
--
ALTER TABLE `detalle_compra`
  MODIFY `id_detalle_compra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  MODIFY `id_detalle_venta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT de la tabla `limpieza`
--
ALTER TABLE `limpieza`
  MODIFY `id_limpieza` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `temporal_compra`
--
ALTER TABLE `temporal_compra`
  MODIFY `id_temporal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=254;

--
-- AUTO_INCREMENT de la tabla `unidades`
--
ALTER TABLE `unidades`
  MODIFY `id_unidades` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id_venta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `fk_compras_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `detalle_compra`
--
ALTER TABLE `detalle_compra`
  ADD CONSTRAINT `fk_detalle_compra` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id_compra`),
  ADD CONSTRAINT `fk_detalle_producto` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`);

--
-- Filtros para la tabla `limpieza`
--
ALTER TABLE `limpieza`
  ADD CONSTRAINT `fk_producto_categoriap` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`),
  ADD CONSTRAINT `fk_producto_unidadp` FOREIGN KEY (`id_unidad`) REFERENCES `unidades` (`id_unidades`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_producto_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`),
  ADD CONSTRAINT `fk_producto_unidad` FOREIGN KEY (`id_unidad`) REFERENCES `unidades` (`id_unidades`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_usuario_caja` FOREIGN KEY (`id_caja`) REFERENCES `cajas` (`id_caja`),
  ADD CONSTRAINT `fk_usuario_rol` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
