-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 01-03-2021 a las 12:55:25
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `fact`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cajas`
--

CREATE TABLE `cajas` (
  `id_caja` int(11) NOT NULL,
  `numero_caja` varchar(10) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `folio` int(11) NOT NULL,
  `activo` tinyint(4) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cajas`
--

INSERT INTO `cajas` (`id_caja`, `numero_caja`, `nombre`, `folio`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(1, '1', 'caja general', 65, 1, '2021-02-13 07:52:30', '2021-02-13 08:52:30'),
(2, '2', 'admin', 52, 1, '2021-02-13 07:45:27', '2021-02-13 08:45:27'),
(3, '23', 'asas', 21, 1, '2021-02-13 07:52:08', '2021-02-13 08:52:08'),
(4, '1', 'asd', 45, 1, '2021-02-22 21:46:19', '2021-02-17 05:02:34'),
(5, '3', 'sdfd', 65, 1, '2021-02-17 05:03:59', '2021-02-17 05:03:59');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_categoria` smallint(6) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categoria`, `nombre`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(1, 'Bebidas2', 1, '2021-02-08 04:19:28', '2021-02-08 05:19:28'),
(2, 'Bebidas 1', 1, '2021-02-08 05:15:52', '2021-02-08 05:15:52');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(50) DEFAULT NULL,
  `text_area` varchar(255) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `id_consulta` int(11) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nombre`, `direccion`, `telefono`, `correo`, `text_area`, `activo`, `id_consulta`, `fecha_alta`, `fecha_edit`) VALUES
(1, 'Mario1', 'Mazatlan Sinaloa1', '66954644441', 'mario1@gmail.com', '', 1, 0, '2021-03-01 05:28:19', '2021-02-25 08:04:17'),
(2, 'Miguel angel', 'asdasdasd', '5566546465', 'miguel@gmail.com', '', 1, 0, '2021-02-08 06:47:43', '2021-02-08 06:47:43'),
(3, 'prueba', 'prueba', '4556464', 'prueba@gmail.com', '', 1, 2, '2021-03-01 05:47:19', '2021-02-25 08:14:29'),
(4, 'prueba25', 'prueba2', '5456546546', 'prueba@gmail.com', 'cdascfascdas\r\n\r\n\r\nasdasd\r\naaaaa54654', 1, 1, '2021-03-01 08:40:49', '2021-03-01 09:40:49'),
(5, 'hugo', 'asasda', '0768767768', 'jaksjhjaSas', 'sjjahsvcas', 1, 0, '2021-03-01 09:25:30', '2021-03-01 09:25:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `id_compra` int(11) NOT NULL,
  `folio` varchar(15) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `compras`
--

INSERT INTO `compras` (`id_compra`, `folio`, `total`, `id_usuario`, `activo`, `fecha_alta`) VALUES
(1, '602fe76417d06', '100.00', 3, 1, '2021-02-19 20:16:59'),
(2, '602fec49c11d3', '80.85', 3, 1, '2021-02-19 20:16:59'),
(3, '60300c3375630', '17.35', 3, 1, '2021-02-19 20:16:59'),
(4, '6037486d1c82b', '50.00', 3, 1, '2021-02-25 07:49:49'),
(5, '603cb7392155a', '10.00', 3, 1, '2021-03-01 10:43:28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `configuracion`
--

CREATE TABLE `configuracion` (
  `id_configuracion` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `valor` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `configuracion`
--

INSERT INTO `configuracion` (`id_configuracion`, `nombre`, `valor`) VALUES
(1, 'tienda_nombre', 'CLINICA MEI'),
(2, 'tienda_rfc', '1'),
(3, 'tienda_telefono', '669 136 0639'),
(4, 'tienda_email', '1'),
(5, 'tienda_direccion', 'Rio Panuco 125, Loma de juarez, Reforma 82030 Mazatlan'),
(6, 'ticket_leyenda', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consultas`
--

CREATE TABLE `consultas` (
  `id_consulta` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `diagnostico` varchar(200) NOT NULL,
  `receta` varchar(200) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `consultas`
--

INSERT INTO `consultas` (`id_consulta`, `id_cliente`, `diagnostico`, `receta`, `fecha_alta`) VALUES
(1, 1, 'Fiebre', 'Tomar 2 paracetamol', '2021-03-01 05:46:23'),
(2, 1, '', 'asdasd', '2021-03-01 05:46:26'),
(3, 2, 'dasda<zs', 'adaD', '2021-03-01 05:46:30'),
(4, 0, '<sfasf', 'asfasdf', '2021-03-01 06:54:39'),
(5, 0, 'zscasf', 'asfs', '2021-03-01 06:57:16'),
(6, 0, 'afsdf', 'sdfsdfs', '2021-03-01 06:59:27'),
(7, 1, 'SCSA', 'ZSS', '2021-03-01 07:49:37'),
(8, 1, 'buena', 'buena', '2021-03-01 08:17:17'),
(9, 2, 'asfsaf', 'asfasf', '2021-03-01 08:56:46'),
(10, 3, 'mbjhvlih', 'bjhvjhvj', '2021-03-01 08:57:23'),
(11, 3, 'sadas', 'asdasd', '2021-03-01 09:03:53'),
(12, 3, 'scc', 'sdcsd', '2021-03-01 09:04:28'),
(13, 1, 'yrueyeyeyreytey', 'jdtteyeyeyeytey', '2021-03-01 09:42:25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_compra`
--

CREATE TABLE `detalle_compra` (
  `id_detalle_compra` int(11) NOT NULL,
  `id_compra` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `detalle_compra`
--

INSERT INTO `detalle_compra` (`id_detalle_compra`, `id_compra`, `id_producto`, `nombre`, `cantidad`, `precio`, `fecha_alta`) VALUES
(1, 1, 2, 'Sabritas', 10, '10.00', '2021-02-19 17:29:46'),
(2, 2, 1, 'ewrwer5', 11, '7.35', '2021-02-19 17:50:49'),
(3, 3, 1, 'ewrwer5', 1, '7.35', '2021-02-19 20:06:50'),
(4, 3, 2, 'Sabritas', 1, '10.00', '2021-02-19 20:06:50'),
(5, 4, 2, 'Sabritas', 5, '10.00', '2021-02-25 07:49:49'),
(6, 5, 2, 'Sabritas', 1, '10.00', '2021-03-01 10:43:28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_venta`
--

CREATE TABLE `detalle_venta` (
  `id_detalle_venta` int(11) NOT NULL,
  `id_venta` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `detalle_venta`
--

INSERT INTO `detalle_venta` (`id_detalle_venta`, `id_venta`, `id_producto`, `nombre`, `cantidad`, `precio`, `fecha_alta`) VALUES
(1, 1, 2, 'Sabritas', 1, '10.00', '2021-02-24 20:19:47'),
(2, 2, 2, 'Sabritas', 3, '10.00', '2021-02-25 07:47:50'),
(3, 3, 2, 'Sabritas', 1, '10.00', '2021-03-01 09:48:55'),
(4, 4, 2, 'Sabritas', 3, '10.00', '2021-03-01 10:39:13'),
(5, 5, 2, 'Sabritas', 2, '10.00', '2021-03-01 10:51:23'),
(6, 6, 2, 'Sabritas', 1, '10.00', '2021-03-01 10:52:45'),
(7, 7, 2, 'Sabritas', 2, '10.00', '2021-03-01 10:55:04'),
(8, 8, 2, 'Sabritas', 2, '10.00', '2021-03-01 10:56:47'),
(9, 9, 2, 'Sabritas', 1, '10.00', '2021-03-01 10:58:33'),
(10, 10, 2, 'Sabritas', 2, '10.00', '2021-03-01 11:01:39'),
(11, 11, 2, 'Sabritas', 2, '10.00', '2021-03-01 11:13:32'),
(12, 11, 3, 'gordo', 2, '12.00', '2021-03-01 11:13:32'),
(13, 12, 2, 'Sabritas', 1, '10.00', '2021-03-01 11:33:23'),
(14, 13, 2, 'Sabritas', 1, '10.00', '2021-03-01 11:36:50'),
(15, 14, 2, 'Sabritas', 1, '10.00', '2021-03-01 11:37:07'),
(16, 15, 2, 'Sabritas', 2, '10.00', '2021-03-01 11:37:29'),
(17, 15, 3, 'gordo', 2, '12.00', '2021-03-01 11:37:29'),
(18, 16, 2, 'Sabritas', 2, '10.00', '2021-03-01 11:40:05'),
(19, 16, 3, 'gordo', 2, '12.00', '2021-03-01 11:40:05'),
(20, 17, 2, 'Sabritas', 2, '10.00', '2021-03-01 11:41:43'),
(21, 17, 3, 'gordo', 2, '12.00', '2021-03-01 11:41:43'),
(22, 18, 2, 'Sabritas', 1, '10.00', '2021-03-01 11:42:19'),
(23, 19, 2, 'Sabritas', 2, '10.00', '2021-03-01 11:54:09'),
(24, 19, 3, 'gordo', 1, '12.00', '2021-03-01 11:54:09'),
(25, 20, 2, 'Sabritas', 1, '10.00', '2021-03-01 12:39:03');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `limpieza`
--

CREATE TABLE `limpieza` (
  `id_limpieza` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `precio_venta` decimal(10,2) NOT NULL,
  `precio_compra` decimal(10,2) NOT NULL DEFAULT 0.00,
  `existencias` int(11) NOT NULL DEFAULT 0,
  `stock_minimo` int(11) NOT NULL DEFAULT 0,
  `inventariable` tinyint(4) NOT NULL,
  `id_unidad` smallint(6) NOT NULL,
  `id_categoria` smallint(6) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `limpieza`
--

INSERT INTO `limpieza` (`id_limpieza`, `codigo`, `nombre`, `precio_venta`, `precio_compra`, `existencias`, `stock_minimo`, `inventariable`, `id_unidad`, `id_categoria`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(1, '1', 'Cloro 2', '12.00', '8.00', 0, 5, 1, 1, 2, 1, '2021-02-24 22:59:07', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `precio_venta` decimal(10,2) NOT NULL,
  `precio_compra` decimal(10,2) NOT NULL DEFAULT 0.00,
  `existencias` int(11) NOT NULL,
  `stock_minimo` int(11) NOT NULL DEFAULT 0,
  `inventariable` tinyint(4) NOT NULL,
  `id_unidad` smallint(6) NOT NULL,
  `id_categoria` smallint(6) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `codigo`, `nombre`, `precio_venta`, `precio_compra`, `existencias`, `stock_minimo`, `inventariable`, `id_unidad`, `id_categoria`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(1, '3242342345', 'ewrwer5', '5.00', '7.35', 14, 33232, 1, 2, 1, 1, '2021-02-19 19:06:50', '2021-02-08 05:07:55'),
(2, '321654', 'Sabritas', '12.00', '10.00', -10, 7, 1, 1, 1, 1, '2021-03-01 11:39:03', '2021-02-07 07:32:13'),
(3, '1212', 'gordo', '2.00', '12.00', -9, 6, 1, 3, 1, 1, '2021-03-01 10:54:09', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `activo` tinyint(4) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id_rol`, `nombre`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(1, 'admin2', 1, '2021-02-17 04:22:18', '2021-02-17 05:22:18'),
(2, 'Moderador', 1, '2021-02-17 04:19:56', '2021-02-17 05:19:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `temporal_compra`
--

CREATE TABLE `temporal_compra` (
  `id_temporal` int(11) NOT NULL,
  `folio` varchar(15) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `temporal_compra`
--

INSERT INTO `temporal_compra` (`id_temporal`, `folio`, `id_producto`, `codigo`, `nombre`, `cantidad`, `precio`, `subtotal`) VALUES
(2, '602feae4a4ea9', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(6, '6033db6505127', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(7, '6033dd973b535', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(8, '6033efab4d654', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(9, '6033efc379011', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(10, '6033f056827f8', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(11, '6033f1b83944f', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(12, '6033f30f15d3a', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(13, '6033f4f322f6f', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(14, '6033f51b63d7d', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(16, '6033f926b9fd5', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(17, '6033f926b9fd5', 1, '3242342345', 'ewrwer5', 1, '7.35', '7.35'),
(18, '60342635cc219', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(19, '60342647a6d58', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(20, '60342c568e49f', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(21, '60342c649b498', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(22, '60342cda14ad4', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(23, '60343485d2876', 2, '321654', 'Sabritas', 3, '10.00', '30.00'),
(24, '603447af1af94', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(25, '60344abedd6b7', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(26, '60344b7eacb06', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(27, '60344d263a28a', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(28, '60352f76d7487', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(29, '603534c14358c', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(30, '6035387644392', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(31, '60353a7c73d9a', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(32, '60353d2781514', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(33, '60353f1a30d99', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(34, '603542801e53d', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(35, '60354370521bb', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(36, '6035447d93d1b', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(37, '60354ce20c7b1', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(38, '60354d03b0164', 2, '321654', 'Sabritas', 2, '10.00', '20.00'),
(39, '60354f849c234', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(40, '6035519130ad2', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(41, '60355627ee5fc', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(42, '603556cb23c2e', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(43, '603558e9dc98c', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(44, '603567540d5a6', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(45, '60357e97bb84e', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(46, '603583727566f', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(47, '603682319157d', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(48, '603684c0447a8', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(49, '603684fe037c0', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(50, '60368527c4735', 2, '321654', 'Sabritas', 3, '10.00', '30.00'),
(51, '60368a3541b6e', 2, '321654', 'Sabritas', 2, '10.00', '20.00'),
(52, '60368a57b6aef', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(53, '60368b4fc2830', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(54, '60368dbe02054', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(55, '60368e26370de', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(56, '60368e60a4a65', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(57, '60368f9c28284', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(58, '60368feccf21e', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(60, '60369462ae450', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(61, '60369543dbb7d', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(62, '6036970ed7143', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(63, '6036977b2db68', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(64, '603699b21913b', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(65, '6036a099771d1', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(66, '6036a6497ec8d', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(67, '6036a683986d6', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(71, '603ca9ed160d8', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(72, '603caa226487d', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(74, '603cac9c83f76', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(75, '603cace5eda3c', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(76, '603cae3f48d70', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(77, '603cae99b90b5', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(78, '603caf0653660', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(79, '603caf7ab45ea', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(80, '603cafc365eaa', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(81, '603cb011a8b9f', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(82, '603cb02488955', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(83, '603cb0cf1cab1', 2, '321654', 'Sabritas', 2, '10.00', '20.00'),
(84, '603cb180b6c6b', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(85, '603cb1d1379c0', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(86, '603cb207c1177', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(87, '603cb26572720', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(88, '603cb2874ecd0', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(89, '603cb2bce49e6', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(90, '603cb30c74751', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(91, '603cb32e5473e', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(92, '603cb36dc11ac', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(93, '603cb3c6d1017', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(94, '603cb40165211', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(95, '603cb41c75376', 2, '321654', 'Sabritas', 2, '10.00', '20.00'),
(96, '603cb4f497945', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(97, '603cb59b3060a', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(98, '603cb5cb14c7c', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(99, '603cb5ea61e73', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(108, '603cbd8f9a8b1', 2, '321654', 'Sabritas', 2, '10.00', '20.00'),
(109, '603cbe2811a28', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(110, '603cbe2811a28', 3, '1212', 'gordo', 1, '12.00', '12.00'),
(113, '603cc0b384553', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(114, '603cc1734aa6c', 2, '321654', 'Sabritas', 2, '10.00', '20.00'),
(115, '603cc1734aa6c', 3, '1212', 'gordo', 1, '12.00', '12.00'),
(116, '603cc1c80a7bd', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(117, '603cc1dcbf5a2', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(118, '603cc202916dc', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(119, '603cc26f778cf', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(120, '603cc2862278c', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(122, '603cc32b66ca2', 2, '321654', 'Sabritas', 1, '10.00', '10.00'),
(135, '603cd3a8875d9', 2, '321654', 'Sabritas', 1, '10.00', '10.00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `unidades`
--

CREATE TABLE `unidades` (
  `id_unidades` smallint(6) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `nombre_corto` varchar(10) NOT NULL,
  `activo` tinyint(3) NOT NULL DEFAULT 1,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `unidades`
--

INSERT INTO `unidades` (`id_unidades`, `nombre`, `nombre_corto`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(1, 'Kilogramo d', 'Kg d', 1, '2021-02-06 06:41:57', '2021-02-06 07:41:57'),
(2, 'Litro', 'Lr', 1, '2021-02-07 03:10:27', '2021-02-07 04:10:27'),
(3, 'piezaz', 'pz', 1, '2021-03-01 09:20:42', '2021-03-01 09:20:42');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `password` varchar(130) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `id_caja` int(11) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `activo` int(11) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_edit` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `usuario`, `password`, `nombre`, `id_caja`, `id_rol`, `activo`, `fecha_alta`, `fecha_edit`) VALUES
(1, 'admin', '123', 'Lab', 1, 1, 1, '2021-02-13 06:18:35', '2021-02-12 07:28:55'),
(2, 'asas5', '$2y$10$l7FGxG7c0PwgWGZOVxCyfeuKcqc/NA7sD7r.v1S7F8zv6KTGnb14e', 'asas', 1, 1, 1, '2021-02-12 06:17:45', '2021-02-12 07:17:45'),
(3, 'mario', '$2y$10$VEmry7wopuk5QXcKwkxm1OHVEr1hTo9BdQMlDlKKs/BQpA9I9BkDm', 'MAriol  labrador avila', 1, 1, 1, '2021-02-13 07:29:18', '2021-02-13 08:29:18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id_venta` int(11) NOT NULL,
  `folio` varchar(15) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `id_usuario` int(11) NOT NULL,
  `id_caja` int(11) NOT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `forma_pago` varchar(5) DEFAULT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id_venta`, `folio`, `total`, `fecha_alta`, `id_usuario`, `id_caja`, `id_cliente`, `forma_pago`, `activo`) VALUES
(1, '6036a6bf79023', '10.00', '2021-02-24 20:19:47', 3, 1, 2, '001', 1),
(2, '6037479a6c939', '30.00', '2021-02-25 07:47:50', 3, 1, 1, '002', 1),
(3, '603caa6cc2378', '10.00', '2021-03-01 09:48:55', 3, 1, 1, '001', 1),
(4, '603cb626ab424', '30.00', '2021-03-01 10:39:13', 3, 1, 1, '001', 1),
(5, '603cb910ca4c5', '20.00', '2021-03-01 10:51:23', 3, 1, 1, '001', 1),
(6, '603cb9682d9da', '10.00', '2021-03-01 10:52:45', 3, 1, 1, '001', 1),
(7, '603cb9ee9a596', '20.00', '2021-03-01 10:55:04', 3, 1, 1, '001', 1),
(8, '603cba56645d8', '20.00', '2021-03-01 10:56:47', 3, 1, 1, '001', 1),
(9, '603cbac59e30d', '10.00', '2021-03-01 10:58:33', 3, 1, 1, '001', 1),
(10, '603cbb7d0cbfc', '20.00', '2021-03-01 11:01:39', 3, 1, 1, '001', 1),
(11, '603cbe3581252', '44.00', '2021-03-01 11:13:32', 3, 1, 1, '001', 1),
(12, '603cc2efb4de5', '10.00', '2021-03-01 11:33:23', 3, 1, 1, '001', 1),
(13, '603cc3bf2b55e', '10.00', '2021-03-01 11:36:50', 3, 1, NULL, NULL, 1),
(14, '603cc3c747f23', '10.00', '2021-03-01 11:37:07', 3, 1, NULL, NULL, 1),
(15, '603cc3d95da63', '44.00', '2021-03-01 11:37:29', 3, 1, NULL, NULL, 1),
(16, '603cc47517067', '44.00', '2021-03-01 11:40:05', 3, 1, NULL, NULL, 1),
(17, '603cc4d7ce753', '44.00', '2021-03-01 11:41:43', 3, 1, NULL, NULL, 1),
(18, '603cc4fc06804', '10.00', '2021-03-01 11:42:19', 3, 1, NULL, NULL, 1),
(19, '603cc7c6c4ee2', '32.00', '2021-03-01 11:54:09', 3, 1, NULL, NULL, 1),
(20, '603cd2502bfe5', '10.00', '2021-03-01 12:39:03', 3, 1, NULL, NULL, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cajas`
--
ALTER TABLE `cajas`
  ADD PRIMARY KEY (`id_caja`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id_compra`),
  ADD KEY `fk_compras_usuario` (`id_usuario`);

--
-- Indices de la tabla `configuracion`
--
ALTER TABLE `configuracion`
  ADD PRIMARY KEY (`id_configuracion`);

--
-- Indices de la tabla `consultas`
--
ALTER TABLE `consultas`
  ADD PRIMARY KEY (`id_consulta`);

--
-- Indices de la tabla `detalle_compra`
--
ALTER TABLE `detalle_compra`
  ADD PRIMARY KEY (`id_detalle_compra`),
  ADD KEY `fk_detalle_compra` (`id_compra`),
  ADD KEY `fk_detalle_producto` (`id_producto`);

--
-- Indices de la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  ADD PRIMARY KEY (`id_detalle_venta`);

--
-- Indices de la tabla `limpieza`
--
ALTER TABLE `limpieza`
  ADD PRIMARY KEY (`id_limpieza`),
  ADD KEY `fk_producto_categoriap` (`id_categoria`),
  ADD KEY `fk_producto_unidadp` (`id_unidad`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD KEY `fk_producto_unidad` (`id_unidad`),
  ADD KEY `fk_producto_categoria` (`id_categoria`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `temporal_compra`
--
ALTER TABLE `temporal_compra`
  ADD PRIMARY KEY (`id_temporal`);

--
-- Indices de la tabla `unidades`
--
ALTER TABLE `unidades`
  ADD PRIMARY KEY (`id_unidades`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `id_caja` (`id_caja`),
  ADD KEY `id_rol` (`id_rol`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id_venta`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cajas`
--
ALTER TABLE `cajas`
  MODIFY `id_caja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id_categoria` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `id_compra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `configuracion`
--
ALTER TABLE `configuracion`
  MODIFY `id_configuracion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `consultas`
--
ALTER TABLE `consultas`
  MODIFY `id_consulta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `detalle_compra`
--
ALTER TABLE `detalle_compra`
  MODIFY `id_detalle_compra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  MODIFY `id_detalle_venta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `limpieza`
--
ALTER TABLE `limpieza`
  MODIFY `id_limpieza` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `temporal_compra`
--
ALTER TABLE `temporal_compra`
  MODIFY `id_temporal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT de la tabla `unidades`
--
ALTER TABLE `unidades`
  MODIFY `id_unidades` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id_venta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `fk_compras_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `detalle_compra`
--
ALTER TABLE `detalle_compra`
  ADD CONSTRAINT `fk_detalle_compra` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id_compra`),
  ADD CONSTRAINT `fk_detalle_producto` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`);

--
-- Filtros para la tabla `limpieza`
--
ALTER TABLE `limpieza`
  ADD CONSTRAINT `fk_producto_categoriap` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`),
  ADD CONSTRAINT `fk_producto_unidadp` FOREIGN KEY (`id_unidad`) REFERENCES `unidades` (`id_unidades`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_producto_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`),
  ADD CONSTRAINT `fk_producto_unidad` FOREIGN KEY (`id_unidad`) REFERENCES `unidades` (`id_unidades`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_usuario_caja` FOREIGN KEY (`id_caja`) REFERENCES `cajas` (`id_caja`),
  ADD CONSTRAINT `fk_usuario_rol` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
